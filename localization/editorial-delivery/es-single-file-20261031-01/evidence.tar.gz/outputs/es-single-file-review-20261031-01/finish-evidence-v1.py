"""Version reconciliation and lossless archival; never generates judgments."""
from pathlib import Path
import sys,json,hashlib,datetime,tarfile,gzip,io,shutil
ROOT=Path('/Users/antonkrutov/Desktop/Forest');sys.path.insert(0,str(ROOT/'tools'))
from locale_efficiency import latest_usage
base=ROOT/'localization/editorial-delivery/es-single-file-20261031-01';out=ROOT/'outputs/es-single-file-review-20261031-01'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binding=lambda p:dict(path=str(p.relative_to(ROOT)),sha256=sha(p),bytes=p.stat().st_size)
rows=lambda p:[json.loads(l) for l in p.read_text().splitlines()]
dump=lambda p,v:p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
assert not (base/'evidence.tar.gz').exists() and not (base/'acceptance.json').exists()
phases={n:out/n for n in ['independent-cli','full-cli','delta-cli']}
for p in phases.values():assert read(p/'process-exit.json')['exitCode']==0
lang=ROOT/'localization/languages/es.json';doc=read(lang);full_path=phases['full-cli']/'review-output/reviews.jsonl';delta_path=phases['delta-cli']/'review-output/reviews.jsonl'
full=rows(full_path);delta=rows(delta_path);assert len(full)==len({r['id'] for r in full})==12825;assert len(delta)==len({r['id'] for r in delta})==254
policy=read(out/'source-policy.json');protected={i for i,h in policy['baselinePreserved'].items() if i in doc['translations'] and hashlib.sha256(doc['translations'][i]['source'].encode()).hexdigest()==h}
assert len(protected)==1781 and all(doc['translations'][i]['source']==doc['translations'][i]['target'] for i in protected)
lookup={}
for path,rs in [(full_path,full),(delta_path,delta)]:
 for line,r in enumerate(rs,1):lookup[r['id']]=(r,path,line)
assert set(lookup).isdisjoint(protected) and set(lookup)|protected==set(doc['translations'])
final=[];preserved=[]
for i,text in doc['translations'].items():
 s=hashlib.sha256(text['source'].encode()).hexdigest();t=hashlib.sha256(text['target'].encode()).hexdigest()
 if i in protected:
  preserved.append(dict(id=i,sourceSha256=s,targetSha256=t,disposition='exact accepted-baseline source policy; no linguistic verdict'));continue
 r,path,line=lookup[i];assert r['reviewed'] is True and r['verdict']=='pass' and r['sourceSha256']==s and r['targetSha256']==t
 assert r['model']=='gpt-6.1-sol' and r['reasoning']=='high' and r['provider']=='openai' and r['reviewerThreadId']=='01a192e3-b09b-7651-8430-373cdab347cb'
 item={k:r[k] for k in ['id','sourceSha256','targetSha256','reviewed','verdict','rationale','reviewerThreadId','model','reasoning','provider']}
 item['originalEvidence']=dict(path=str(path.relative_to(ROOT)),sha256=sha(path),line=line)
 final.append(item)
for name,rs in [('complete-reviews.jsonl',final),('source-preserved.jsonl',preserved)]:
 (base/name).write_text(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in rs))
reports=base/'review-reports';reports.mkdir()
for p,name in [(phases['independent-cli']/'consolidated-report.md','initial.md'),(phases['full-cli']/'report.md','full.md'),(phases['delta-cli']/'report.md','delta.md')]:shutil.copyfile(p,reports/name)
artifact=ROOT/'dist/Forest-es-e463841a59ea';m=read(artifact/'manifest.json');assert m['languageSha256']==sha(lang)
for name,b in m['files'].items():assert sha(artifact/name)==b['sha256']
shutil.copyfile(artifact/'manifest.json',base/'build-manifest.json');shutil.copyfile(out/'final-static-verification.json',base/'static-verification.json')
rt=read(phases['delta-cli']/'runtime-verification.json');usage=latest_usage(Path(rt['sessionMetadataPath']));assert usage['total_tokens']==50860282
first=read(phases['full-cli']/'runtime-verification.json')['baselineUsage'];second=rt['baselineUsage']
def difference(a,b):return {k:a[k]-b.get(k,0) for k in a}
usage_record=dict(reviewer=dict(threadId=rt['threadId'],model='gpt-6.1-sol',reasoning='high',provider='openai',initialHistory='fresh exec; null parent',subsequentHistory='same assignment only; no parent history or second reviewer'),phases=[dict(name='initial-1134',usage=first),dict(name='glossary-restart-12825',usage=difference(second,first)),dict(name='final-delta-254',usage=difference(usage,second))],total=usage,measurement='Actual same-session nonoverlapping cumulative deltas, reconciled after terminal CLI exits. Cached input is part of input; reasoning is part of output; neither added twice.',cutoff=read(phases['delta-cli']/'process-exit.json')['finishedAt'],coordinator=dict(status='unknown',scope='Preparation, dispatch, monitoring, follow-ups, result review and accounting mixed with author proofreading; desktop root telemetry unavailable. Git/reporting tail unmeasured.'),descendantAgents='none',platformOverhead='not exposed; token counts are not monetary charges')
dump(base/'usage.json',usage_record)
# Archive the complete original inputs, immutable cycles, raw model decisions,
# runtime receipts, execution snapshot and orchestration evidence losslessly.
exclude={base/n for n in ['complete-reviews.jsonl','source-preserved.jsonl','build-manifest.json','static-verification.json','usage.json','acceptance.json','evidence-index.json','evidence.tar.gz','README.md','.gitignore']}
paths={p for folder in [base,out] for p in folder.rglob('*') if p.is_file() and p not in exclude and not p.is_relative_to(reports)}
paths|={ROOT/'localization/glossary/en.json',ROOT/'localization/glossary/es.json',ROOT/'assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json',ROOT/'localization/source/gallery-chapter-display-20261028/admission-v1/consumer-context.jsonl',ROOT/'localization/framework/forest045-shared-v2/framework.json'}
paths=sorted(paths);index=[];archive=base/'evidence.tar.gz';temporary=archive.with_suffix('.gz.pending')
with temporary.open('xb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=9) as zipped:
  with tarfile.open(fileobj=zipped,mode='w|') as tar:
   for p in paths:
    data=p.read_bytes();name=str(p.relative_to(ROOT));digest=hashlib.sha256(data).hexdigest();info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data));index.append(dict(path=name,bytes=len(data),sha256=digest))
temporary.replace(archive)
with tarfile.open(archive,'r:gz') as tar:
 members=tar.getmembers();assert [m.name for m in members]==[r['path'] for r in index]
 for member,expected in zip(members,index):assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==expected['sha256']
dump(base/'evidence-index.json',dict(archive=binding(archive),members=index,verifiedMembers=len(index),originals='Uncompressed local originals preserved; archive stores exact original bytes and relative paths. No game/saves/history files deleted.'))
acceptance=dict(schemaVersion=1,game='The Forest of Love',gameVersion='0.45',locale='es',culture='es-ES',scope='Editorial acceptance of the complete single-file catalog; no claim of additional credits/image-text inventory or native/release acceptance.',status='editorial-passed;static-build-passed;native-not-run',language=binding(lang),framework=binding(ROOT/'localization/framework/forest045-shared-v2/framework.json'),glossary={code:binding(base/f'repair-01/glossary/{code}.json') for code in ['en','es']},counts=dict(total=14606,semanticReviewed=12825,semanticPass=12825,sourcePreserved=1781,missing=0,unread=0,objectiveFindings=0,needsContext=0,changedTargets=67,finalDelta=254,finalCorrected=4,finalUnchangedRegressions=250),semanticReviews=binding(base/'complete-reviews.jsonl'),sourcePreservation=binding(base/'source-preserved.jsonl'),archive=binding(archive),archiveIndex=binding(base/'evidence-index.json'),build=dict(artifact=str(artifact.relative_to(ROOT)),manifest=binding(base/'build-manifest.json'),files=16,buildPassed=True,checkModePassed=True,installed=False),staticVerification=binding(base/'static-verification.json'),usage=binding(base/'usage.json'),model=dict(model='gpt-6.1-sol',reasoning='high',provider='openai',independentReviewerCount=1,threadId=rt['threadId']),native='not-run',runtime='not-run',fontsAndLayout='not-accepted',release='not-accepted',publication='not-run',deployment='not-run',oldLocaleQueues='owner-stopped;not-resumed',at=datetime.datetime.now(datetime.timezone.utc).isoformat())
dump(base/'acceptance.json',acceptance)
print(json.dumps(dict(semanticPass=len(final),sourcePreserved=len(preserved),archiveMembers=len(index),archiveMiB=round(archive.stat().st_size/1048576,2),completeReviewsMiB=round((base/'complete-reviews.jsonl').stat().st_size/1048576,2),acceptance=binding(base/'acceptance.json')),ensure_ascii=False))
