"""Resolve explicit reviewer-authored memberships; never supply a verdict or rationale."""
import hashlib
import json
from pathlib import Path

root = Path('/Users/antonkrutov/Desktop/Forest')
phase = root / 'outputs/es-single-file-review-20261031-01/delta-cli'
base = root / 'localization/editorial-delivery/es-single-file-20261031-01/repair-02'
load = lambda path: [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
task = json.loads((phase / 'task.json').read_text())['task']
assert sha(root / task['reviewPacket']) == task['reviewPacketSha256']
packet = {row['id']: row for row in load(root / task['reviewPacket'])}
members = json.loads((base / 'group-membership.json').read_text())
view = {row['group']: row for row in load(base / 'reading-view.jsonl')}
registered = {row['id'] for row in load(base / 'registered-semantic-context.jsonl')}
decisions = load(phase / 'decisions.jsonl')
reuse = {row['id']: row for row in json.loads((phase / 'context-reuse.json').read_text())}
seen = set()
rows = []
expanded = []
for index, decision in enumerate(decisions):
    assert decision.get('verdict') in {'pass', 'finding', 'needs-context'}
    assert isinstance(decision.get('rationale'), str) and decision['rationale'].strip()
    groups = list(decision.get('groups', []))
    for key in ['range', 'range2']:
        if key in decision:
            start, end = decision[key]
            groups.extend('R' + str(number).zfill(3) for number in range(start, end + 1))
    ids = []
    for group in groups:
        assert members[group] == view[group]['ids']
        for ident in members[group]:
            assert all(view[group][key] == packet[ident][key] for key in ['source', 'target'])
        ids.extend(members[group])
    assert ids and len(ids) == len(set(ids)) and not seen.intersection(ids)
    for ident in ids:
        item = packet[ident]
        evidence = [{'path': str((base / 'reading-view.jsonl').relative_to(root)), 'sha256': sha(base / 'reading-view.jsonl')}]
        if ident in reuse:
            evidence.append(reuse[ident])
        if ident in registered:
            evidence.append({'path': str((base / 'registered-semantic-context.jsonl').relative_to(root)), 'sha256': sha(base / 'registered-semantic-context.jsonl'), 'id': ident})
            evidence.append({'path': str((phase / 'gallery-assembled-reading.json').relative_to(root)), 'sha256': sha(phase / 'gallery-assembled-reading.json')})
        if 'R003' in groups:
            evidence.append({'path': str((base / 'callback-context.jsonl').relative_to(root)), 'sha256': sha(base / 'callback-context.jsonl')})
        if ident.startswith('ds:') or 'R003' in groups:
            evidence.append({'path': str((base / 'dialogue-context.json').relative_to(root)), 'sha256': sha(base / 'dialogue-context.json')})
        row = dict(id=ident, reviewed=True, verdict=decision['verdict'], rationale=decision['rationale'],
                   sourceSha256=item['sourceSha256'], targetSha256=item['targetSha256'],
                   decisionIndex=index, contextEvidence=evidence)
        if 'proposedTarget' in decision:
            row['proposedTarget'] = decision['proposedTarget']
        rows.append(row)
    expanded.append(dict(decisionIndex=index, groups=groups, ids=ids, verdict=decision['verdict'], rationale=decision['rationale']))
    seen.update(ids)
assert seen == set(packet) and len(rows) == 254
for name, items in [('expanded-decisions.jsonl', expanded), ('judgments.jsonl', rows)]:
    with (phase / name).open('x') as stream:
        for item in items:
            stream.write(json.dumps(item, ensure_ascii=False) + '\n')
print(json.dumps({'explicitDecisions': len(decisions), 'reviewed': len(rows), 'unread': len(set(packet) - seen)}))
