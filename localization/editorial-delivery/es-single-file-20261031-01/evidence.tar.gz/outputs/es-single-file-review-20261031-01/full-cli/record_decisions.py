"""Attach exact pinned memberships to explicit model-authored decisions only."""
import sys,json,hashlib
from pathlib import Path
root=Path('/Users/antonkrutov/Desktop/Forest');phase=root/'outputs/es-single-file-review-20261031-01/full-cli';base=root/'localization/editorial-delivery/es-single-file-20261031-01/repair-01/full-review'
load=lambda p:[json.loads(l) for l in p.read_text().splitlines()]
packet=load(base/'review-packet.jsonl');byid={r['id']:r for r in packet};m=json.loads((base/'semantic-reading-manifest.json').read_text());ui={r['group']:(r,p) for p in m['uiPages'] for r in load(root/p['path'])}
old=load(phase/'judgments.jsonl') if (phase/'judgments.jsonl').exists() else [];seen={r['id'] for r in old};new=[];decisions=[]
for line in sys.stdin:
 if not line.strip():continue
 d=json.loads(line);assert d.get('verdict') in ['pass','finding','needs-context'] and d.get('rationale')
 ids=list(d.get('ids',[]));evidence=[]
 if 'uiRange' in d:d['uiGroups']=['UI'+str(i).zfill(4) for i in range(d['uiRange'][0],d['uiRange'][1]+1)]
 for g in d.get('uiGroups',[]):
  r,p=ui[g];ids+=r['ids'];evidence.append({'page':p['path'],'pageSha256':p['sha256'],'group':g})
 if 'dialoguePage' in d:
  p=m['dialoguePages'][d['dialoguePage']-1];pp=root/p['path'];assert hashlib.sha256(pp.read_bytes()).hexdigest()==p['sha256']
  selected=[]
  for raw in pp.read_text().splitlines():
   if raw.startswith('SCENE '):cid=int(raw.split(' ',2)[1]);continue
   r=json.loads(raw)
   if cid in d.get('scenes',[]) and (not d.get('entries') or r['entry'] in d['entries']):selected.extend(x['id'] for x in r.get('primary',[]))
  ids+=selected;evidence.append({'page':p['path'],'pageSha256':p['sha256'],'scenes':d['scenes'],'entries':d.get('entries')})
 assert ids and len(ids)==len(set(ids)) and not seen.intersection(ids),ids
 assert set(ids)<=byid.keys()
 d['members']=[{'id':i,'sourceSha256':byid[i]['sourceSha256'],'targetSha256':byid[i]['targetSha256']} for i in ids];d['contextEvidence']=evidence;d['decisionIndex']=len(load(phase/'decisions.jsonl'))+len(decisions) if (phase/'decisions.jsonl').exists() else len(decisions)
 for member in d['members']:
  r=dict(member,reviewed=True,verdict=d['verdict'],rationale=d['rationale'],decisionIndex=d['decisionIndex'],contextEvidence=evidence)
  if d.get('proposedTarget') is not None:r['proposedTarget']=d['proposedTarget']
  new.append(r)
 seen.update(ids);decisions.append(d)
for name,rows in [('decisions.jsonl',decisions),('judgments.jsonl',new)]:
 with (phase/name).open('a') as f:
  for row in rows:f.write(json.dumps(row,ensure_ascii=False)+'\n')
pending=[r['id'] for r in packet if r['id'] not in seen]
(phase/'reading-checkpoint.json').write_text(json.dumps({'reviewedIds':len(seen),'unreadIds':len(pending),'unreadIdList':pending,'packetSha256':m.get('packetSha256',hashlib.sha256((base/'review-packet.jsonl').read_bytes()).hexdigest()),'status':'in-progress','rule':'Only explicit model judgments create reviewed coverage; pending IDs have no verdict.'},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'added':len(new),'reviewed':len(seen),'unread':len(pending)}))
