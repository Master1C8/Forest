"""Bounded text rendering only. Never creates review judgments."""
import json,sys,hashlib
from pathlib import Path
root=Path('/Users/antonkrutov/Desktop/Forest');phase=root/'outputs/es-single-file-review-20261031-01/full-cli';base=root/'localization/editorial-delivery/es-single-file-20261031-01/repair-01/full-review'
m=json.loads((base/'semantic-reading-manifest.json').read_text());arg=sys.argv[1];pages=m['uiPages'] if arg.startswith('u') else m['dialoguePages'];page=pages[int(arg[1:])-1];src=root/page['path'];assert hashlib.sha256(src.read_bytes()).hexdigest()==page['sha256']
if arg.startswith('u'):
 rows=[json.loads(l) for l in src.read_text().splitlines()];lines=[]
 aliases={ident:'M'+str(i+1) for i,ident in enumerate(page['ids'])}
 (phase/(arg+'-members.json')).write_text(json.dumps(aliases,ensure_ascii=False,indent=2)+'\n')
 mechanical={'selector','object','pathId','resource','property','disposition','renderer','profiles','ancestors'}
 def semantic(x):
  if isinstance(x,list):return [semantic(v) for v in x]
  if isinstance(x,dict):return {k:semantic(v) for k,v in x.items() if k not in mechanical}
  if isinstance(x,str):
   if x in aliases:return aliases[x]
   for a,b in [('LevelSingletons/PauseScreenUI/Pause Screen Ui Panel','PAUSE'),('Canvas','START'),('NameContainer (1)','NC1'),('NameContainer','NC'),('NameGlowLeft','GL'),('NameGlowTop','GT'),('NameGlowRight','GR'),('NameGlowBottom','GB'),('Controls/MainControls','MC')]:x=x.replace(a,b)
  return x
 lines.append('Member aliases resolve exactly in '+arg+'-members.json. Selectors and mechanical object/resource/style metadata remain in pinned pages; all wording and semantic evidence below. Macros: START=Canvas; PAUSE=LevelSingletons/PauseScreenUI/Pause Screen Ui Panel; NC/NC1=NameContainer/(1); GL/GT/GR/GB=NameGlowLeft/Top/Right/Bottom; MC=Controls/MainControls.')
 for r in rows:
  lines.append(r['group']+' '+json.dumps([r['source'],r['target']],ensure_ascii=False)+' members='+','.join(aliases[i] for i in r['ids']))
  seen={}
  for c in r['contexts']:
   ev=semantic(c['evidence'])
   for item in ev:
    if item.get('sourceUnit',{}).get('context')==item.get('hierarchy') and item.get('hierarchy'):item['sourceUnit']['context']='=hierarchy'
   key=json.dumps(ev,ensure_ascii=False,sort_keys=True,separators=(',',':'))
   if key in seen:lines.append(aliases[c['id']]+' same-context-as='+seen[key])
   else:
    seen[key]=aliases[c['id']];lines.append(aliases[c['id']]+' '+json.dumps(ev,ensure_ascii=False,separators=(',',':')))

else:
 lines=[]
 for raw in src.read_text().splitlines():
  if raw.startswith('SCENE '):lines.append(raw);continue
  r=json.loads(raw);primary=r.pop('primary',[])
  head='E'+str(r.pop('entry'))+' '+r.pop('actor')+'>'+r.pop('conversant')+' ->'+json.dumps(r.pop('links'),separators=(',',':'))
  if primary:
   for x in primary:lines.append(head+' '+x['id']+' '+json.dumps([x['source'],x['target']],ensure_ascii=False))
  if r or not primary:lines.append(head+' ctx='+json.dumps(r,ensure_ascii=False,separators=(',',':')))
text='\n'.join(lines)+'\n';view=phase/(arg+'-reading.txt');view.write_text(text)
a=int(sys.argv[2]) if len(sys.argv)>2 else 0;b=int(sys.argv[3]) if len(sys.argv)>3 else len(lines)
print('PAGE',arg,'SOURCE',page['path'],'LINES',len(lines),'CHARS',len(text),'RANGE',a,b)
print('\n'.join(f'{i}: {l}' for i,l in enumerate(lines[a:b],a)))
