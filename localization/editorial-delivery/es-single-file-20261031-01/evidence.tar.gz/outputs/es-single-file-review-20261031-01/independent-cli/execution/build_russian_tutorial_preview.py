#!/usr/bin/env python3
"""Compose the proven Russian dialogue preview with verified tutorial resources."""
import pathlib,json,subprocess,hashlib,argparse,sys,copy
from tutorial_sprite_patch import apply
ROOT=pathlib.Path(__file__).resolve().parents[1]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def build(output,product,manifest,locale):
 if locale!='ru':raise ValueError('Explicit supported locale ru required')
 assert ROOT in output.resolve().parents and not output.exists()
 data=json.loads(manifest.read_text());assert data['locale']=='ru' and data['textures'];source=json.loads((ROOT/data['sourceSpriteManifest']).read_text());src={r['id']:r for r in source['records']};entries=[]
 for e in data['textures']:
  r=src[e['id']];assert e['sourceSha256']==r['sha256'];assert (e['width'],e['height'],e['format'])==(r['width'],r['height'],r['format']);assert sha(ROOT/e['path'])==e['sha256'];entries.append(dict(r,path=e['path'],sha256=e['sha256']))
 command=[sys.executable,'-B',str(ROOT/'tools/build_russian_preview.py'),'--output',str(output),'--qa-product',product,'--repair-cyrillic-metrics','--coherent-legacy-face','--coherent-tmp-face','--coherent-choice-face'];subprocess.run(command,cwd=ROOT,check=True)
 base=output/'build.json';(output/'base-dialogue-build.json').write_bytes(base.read_bytes());report=json.loads(base.read_text());receipts=[]
 for asset in sorted({e['sourceFile'] for e in entries}):
  path=output/'game/The Forest of Love_Data'/asset;receipt=apply(path,[e for e in entries if e['sourceFile']==asset],ROOT,output/('tutorial-readback-'+asset+'.json'));receipts.append(receipt)
  existing=next((x for x in report['files'] if x['path']==asset),None)
  if existing:existing.update(probeSha256=sha(path),tutorialTextureAndSpriteReadback=receipt)
  else:report['files'].append({'path':asset,'sourceSha256':next(e['sourceFileSha256'] for e in entries if e['sourceFile']==asset),'probeSha256':sha(path),'tutorialTextureAndSpriteReadback':receipt})
 report.update(tutorialTextures={'manifest':str(manifest.relative_to(ROOT)),'manifestSha256':sha(manifest),'count':len(entries),'sourceBoundSpriteGeometry':'full-rect render mesh + exact texture pixel readbacks; old tight outlines do not clip new glyphs','baseDialogueBuildSha256':sha(output/'base-dialogue-build.json'),'runtime':'not-run','visual':'see independent per-image evidence'},runtime='not-run',visual='not-run');base.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
 for name in ['build_russian_tutorial_preview.py','tutorial_sprite_patch.py']: (output/name).write_bytes((ROOT/'tools'/name).read_bytes())
 print(json.dumps({'output':str(output),'tutorials':len(entries),'files':len(report['files']),'runtime':'not-run'}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--locale',required=True);p.add_argument('--output',required=True,type=pathlib.Path);p.add_argument('--qa-product',required=True);p.add_argument('--textures',required=True,type=pathlib.Path);a=p.parse_args();build(a.output.resolve(),a.qa_product,a.textures.resolve(),a.locale)
