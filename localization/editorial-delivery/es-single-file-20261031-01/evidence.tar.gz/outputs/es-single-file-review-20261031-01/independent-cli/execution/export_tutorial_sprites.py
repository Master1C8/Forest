#!/usr/bin/env python3
"""Export actual tutorial Sprite meshes, never unmasked Texture2D padding."""
import pathlib,json,hashlib,argparse,UnityPy
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[1];SOURCE=pathlib.Path('/Volumes/KINGSTONMAC/CrossOver/Bottles/Steam/drive_c/forest/The Forest of Love_Data')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def export(output):
 assert not output.exists(),'Use a new immutable extraction directory'
 alltex=json.loads((ROOT/'assets/source-v2/textures.json').read_text());selected=[r for r in alltex if 'tutorial'in r.get('name','').lower()];assert len(selected)==18
 pinned=json.loads((ROOT/'assets/source-v2/source-files.json').read_text());records=[];images=[];output.mkdir(parents=True)
 for asset in sorted({r['sourceFile'] for r in selected}):
  path=SOURCE/asset;assert sha(path)==pinned[asset]['sha256'];env=UnityPy.load(str(path));wanted={r['pathId']:r for r in selected if r['sourceFile']==asset};sprites=[]
  for o in env.objects:
   if o.type.name!='Sprite':continue
   t=o.read_typetree();ref=t['m_RD']['texture']
   if ref['m_FileID']==0 and ref['m_PathID'] in wanted:
    r=wanted[ref['m_PathID']];sp=o.read();trimmed=sp.image.convert('RGBA');rect=t['m_RD']['textureRect'];origin=(round(rect['x']),round(r['height']-rect['y']-rect['height']));im=Image.new('RGBA',(r['width'],r['height']));im.paste(trimmed,origin);out=output/(r['name']+'--sprite-'+str(o.path_id)+'.png');im.save(out)
    rec={'id':asset+':Sprite:'+str(o.path_id),'textureId':r['id'],'name':t['m_Name'],'sourceFile':asset,'sourceFileSha256':sha(path),'spritePathId':o.path_id,'texturePathId':ref['m_PathID'],'spriteRect':t['m_Rect'],'spritePivot':t['m_Pivot'],'pixelsToUnits':t['m_PixelsToUnits'],'meshVertices':t['m_RD']['m_VertexData']['m_VertexCount'],'indicesBytes':len(t['m_RD']['m_IndexBuffer']),'image':str(out.relative_to(ROOT)),'sha256':sha(out),'width':im.width,'height':im.height,'format':r['format'],'rawTextureExport':r['path'],'rawTextureExportSha256':r['sha256'],'method':'UnityPy Sprite.image: actual Sprite render mesh masks dilated unused texture texels; no resize','packingSettings':t['m_RD']['settingsRaw']};records.append(rec);sprites.append(ref['m_PathID'])
  for pid,r in wanted.items():
   if pid not in sprites:records.append({'textureId':r['id'],'name':r['name'],'sourceFile':asset,'sourceFileSha256':sha(path),'texturePathId':pid,'classification':'Texture-only tutorial companion; no local Sprite consumer','rawTextureExport':r['path'],'rawTextureExportSha256':r['sha256'],'format':r['format']})
 manifest={'schemaVersion':1,'game':'The Forest of Love','version':'0.45','scope':'All18 tutorial-named original Texture2D resources and every local Sprite consumer; source append-only, no dialogue/glossary mutation','sourceInventorySha256':sha(ROOT/'assets/source-v2/textures.json'),'records':records,'boundary':'Raw Texture2D PNGs contain intentionally dilated nonvisible pixels. They are not the rendered Sprite. Source reading/removal must use source-bound Sprite mesh images; new lettering requires corresponding Sprite geometry acceptance. Other complete-game source gates unchanged.'};(output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'records':len(records),'sprites':len([r for r in records if 'image'in r]),'output':str(output)}))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args();export(a.output.resolve())
