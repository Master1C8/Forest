"""Finite, source-bound Japanese author delta; no model or shared helper writes."""
import base64
import hashlib
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
sys.path.insert(0, str(ROOT))
from tools.forest_localization.core import encode

P = Path(__file__).resolve().parent
def read(p): return json.loads(Path(p).read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def lines(p): return [json.loads(x) for x in Path(p).read_text().splitlines()]
seed = read(P / 'primary-input.json')
language = read(ROOT / 'localization/languages/ja.json')
assert language == seed, 'Concurrent or unexpected language mutation'
primary = lines(P / 'primary-rows.jsonl')
resources = lines(P / 'resource-rows-context.jsonl')
by_id = {x['id']: x for x in primary}
changes = {}
def put(id, target, reason, evidence=None):
    row = language['translations'][id]
    assert id in by_id and row['source'] == by_id[id]['source']
    assert isinstance(target, str) and target
    if target == row['target']: return
    assert id not in changes or changes[id]['target'] == target
    changes[id] = dict(id=id, source=row['source'], target=target,
        previousTarget=row['target'], sourceSha256=sha(row['source'].encode()),
        targetSha256=sha(target.encode()), reason=reason, evidence=evidence)
    row['target'] = target

recovery = read(P / 'missing-target-recovery.json')
lookup = {}
for x in recovery['matches']:
    if not x['candidates']: continue
    assert len(x['candidates']) == 1
    c = x['candidates'][0]
    lookup[x['source']] = (c['target'], c['owners'])
supplement = ROOT / 'localization/supplemental-ui/20261027/ja.jsonl'
supplement_sha = sha(supplement.read_bytes())
for x in lines(supplement):
    if x['source'] not in lookup:
        lookup[x['source']] = (x['target'], [dict(path=str(supplement.relative_to(ROOT)), sha256=supplement_sha, id=x['id'])])
menu = {'Active':'進行中', 'Completed':'完了', 'Gallery':'ギャラリー',
        'Play':'プレイ', 'Report a Bug':'不具合を報告', 'Options\n':'オプション\n',
        'Start New Game':'ニューゲーム'}
for x in primary:
    if x['target'] is not None: continue
    s = x['source']
    if s in lookup:
        t, owners = lookup[s]
        put(x['id'], t, 'Recovered own exact-source authored Japanese; source/consumer read in current primary pass.', owners)
    elif s in menu:
        put(x['id'], menu[s], 'Authored menu/status label from exact registered consumer; newline retained.')
    else:
        raise ValueError(('Unresolved null', x['id'], s))

staging = {
 '**Fade to black**':'**暗転**', '**Next image**':'**次の画像**',
 '1st attempt':'1回目の挑戦', '2nd attempt':'2回目の挑戦', '3rd attempt':'3回目の挑戦',
 '4th':'4回目', '5th and looped.':'5回目。その後は繰り返し。',
 'Rascal':'ラスカル', 'Charlotte':'シャーロット', 'Melody':'メロディ',
 'Rebecka':'レベッカ', 'Marygold':'マリーゴールド', 'Mary gold':'マリーゴールド',
 'Bear 1':'クマ1', 'Bear 2':'クマ2', 'Bucky':'バッキー',
 'Scene:':'場面：', 'Text on the black screen:':'暗転中に表示する文章：',
 '*Fade in illustration*':'*イラストをフェードイン*',
 '*Fade to next illustration*':'*次のイラストにフェード*',
 '*Fade to Cumshot*':'*射精のイラストにフェード*',
 '*Fade to Cum Shot*':'*射精のイラストにフェード*',
 '*Fade to black*':'*暗転*', '*Fade to Black*':'*暗転*',
 '*Fade to Illustration*':'*イラストにフェード*', '*Fade to illustration*':'*イラストにフェード*',
 '*Fade into illustration 1*':'*イラスト1をフェードイン*',
 '*Fade into Illustration 1*':'*イラスト1をフェードイン*',
 '*Fade into first illustration*':'*最初のイラストをフェードイン*',
 '*Fade next illustration':'*次のイラストにフェード',
 '*Fade to black. Hold the black screen while this dialogue plays out*':'*暗転。この会話が終わるまで暗転を保つ*',
 '*Fade to Illustration 2 (Rascal Cumming)*':'*イラスト2（ラスカルの射精）にフェード*',
 '*Fade to Illustration 3 Bucky cumming. (We could have a moment where rascal stops cumming and it fades to the post scene for just him?*':'*イラスト3、バッキーの射精にフェード。（ラスカルが射精を終えた時点で、彼だけ先に事後の絵へフェードする瞬間を入れてもいい？*',
 '*Fade to full post illustration*':'*全員が事後の状態になったイラストにフェード*',
 '*Fade to Illustration 3 (Licking)*':'*イラスト3（舐める）にフェード*',
 '*Fade to illustration 4 (cum)*':'*イラスト4（射精）にフェード*',
}
for n in range(2, 7):
    for s in (f'*Fade to {n}*', f'*fade to {n}*', f'*Fade to Illustration {n}*', f'*Fade to illustration {n}*', f'*fade to illustration {n}*'):
        staging[s] = f'*イラスト{n}にフェード*'
for name in ('Rascal','Charlotte','Melody','Rebecka','Marygold','Mary gold','Bear 1','Bear 2','Bucky'):
    staging[name+':'] = staging[name]+'：'
for x in primary:
    if x['source'] == x['target'] and x['source'] in staging:
        put(x['id'], staging[x['source']], 'Nonpreserved displayed staging/speaker wording; exact source context read; controls remain outside target.')

for f in lines(P / 'findings.jsonl'):
    print('FINDING', f.keys())
    target = f.get('proposedTarget', f.get('proposal', f.get('target')))
    assert target, f
    put(f['id'], target, f.get('reason', f.get('finding','Source/context adjudicated objective repair')), f)

for x in resources:
    consumers = x.get('consumerContext', [])
    paths = [c['hierarchy'] for c in consumers]
    for h in paths:
        match = re.match(r'(Purple|Blue|Red|Green)BellItemNotification/Page1/Title \(2\)(?:/|$)', h)
        if match:
            color, copula = {'Purple':('紫','の'),'Blue':('青','い'),'Red':('赤','い'),'Green':('緑','の')}[match[1]]
            put(x['id'], f'<size=22>{color}</size>{copula}<size=22>ベル</size>',
                'Full active bell title follows exact family consumer, not cloned BLUE source; both emphasis concepts nonempty.', paths)

# Source-faithful bug question. This optional bad-choice family keeps a disclosed
# seven-mora final line rather than dropping work to manufacture strict 5-7-5.
for x in primary:
    if x['source'] == 'Why must you work now?':
        put(x['id'], '今なぜ勤む', 'Haiku bug choice: retain now/why/work as a rhetorical necessity question; ima-naze-tsutomu=7, disclosed meter exception; exact display/evaluation pair.')

face = ROOT / 'localization/fonts/noto-cjk/NotoSansCJKjp-Regular.otf'
face_bytes = face.read_bytes()
face_sha = sha(face_bytes)
assert face_sha == '68a3fc98800b2a27b371f2fb79991daf3633bd89309d4ffaa6946fd587f375b5'
framework = read(ROOT / 'localization/framework/forest045-shared-v2/framework.json')
language['fontAssets'] = {face_sha: base64.b64encode(face_bytes).decode('ascii')}
language['fonts'] = {key:dict(asset=face_sha, family='Noto Sans CJK JP') for key in framework['fontRoles']}
assert len(language['fonts']) == 8
assert all(v['target'] is not None for v in language['translations'].values())
(P / 'authored-delta.jsonl').write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True)+'\n' for x in sorted(changes.values(),key=lambda x:x['id'])))
destination = ROOT / 'localization/languages/ja.json'
destination.write_bytes(encode(language))
print(json.dumps(dict(changes=len(changes), nullTargets=0, languageSha256=sha(destination.read_bytes()),fontRoles=8)))
