"""Bind actual author readings and finite review closure; generate no pass verdicts."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
P = Path(__file__).resolve().parent
D = ROOT / 'localization/editorial-delivery/ja-single-file-20261101-01'
def read(p): return json.loads(Path(p).read_text())
def rows(p): return [json.loads(x) for x in Path(p).read_text().splitlines()]
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def textsha(s): return hashlib.sha256(s.encode()).hexdigest()
def write(p,obj):
    with Path(p).open('x') as f: f.write(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
def jsonl(p,rs):
    with Path(p).open('x') as f:
        for r in rs:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n')

language = ROOT / 'localization/languages/ja.json'
l = read(language)
seed = read(P/'primary-input.json')
primary = rows(P/'primary-rows.jsonl')
delta = rows(P/'authored-delta.jsonl')
changes = {r['id']:r for r in delta}
preserved = read(ROOT/'localization/completion/ja-single-file-20261101-01/source-preservation.json')['baselinePreserved']
assert len(primary)==12825 and len(preserved)==1781
assert set(r['id'] for r in primary) == set(l['translations'])-set(preserved)
assert {k for k in l['translations'] if l['translations'][k]!=seed['translations'][k]} == set(changes)
catalog = read(ROOT/'localization/framework/forest045-shared-v2/catalog.json')
if isinstance(catalog,dict): catalog=catalog['entries']
sources={r['id']:r['source'] for r in catalog}
assert len(sources)==14606
for k,v in l['translations'].items(): assert v['source']==sources[k]
preservation=[]
for k,h in preserved.items():
    v=l['translations'][k]
    assert textsha(v['source'])==h and v['target']==v['source']
    preservation.append(dict(id=k,sourceSha256=h,targetSha256=h,equal=True,acceptance='exact-preservation-only; no linguistic verdict'))

assert not D.exists() or not any(D.iterdir()), 'Preserve an existing delivery'
D.mkdir(parents=True,exist_ok=True)
(D/'ja.json').write_bytes(language.read_bytes())
packet=[];bindings=[]
resources={r['id']:r for r in rows(P/'resource-rows-context.jsonl')}
for r in primary:
    v=l['translations'][r['id']]
    q=dict(id=r['id'],source=v['source'],target=v['target'],sourceSha256=textsha(v['source']),targetSha256=textsha(v['target']),ordinal=r['ordinal'],context=r['context'])
    if r['id'] in resources:q['consumerContext']=resources[r['id']].get('consumerContext',[])
    packet.append(q)
    bindings.append(dict(id=q['id'],ordinal=q['ordinal'],sourceSha256=q['sourceSha256'],initialTargetSha256=r['targetSha256'],finalTargetSha256=q['targetSha256'],readEvidence='reading-ledger.jsonl; context-closure.json; authored-delta self-read if changed',authoredDelta=(r['id'] in changes),boundary='Reading/version binding only; no generated pass verdict'))
jsonl(D/'primary-packet.jsonl',packet)
jsonl(D/'authored.jsonl',delta)
jsonl(D/'primary-reading-bindings.jsonl',bindings)
jsonl(D/'source-preservation-proof.jsonl',preservation)
(D/'reading-ledger.jsonl').write_bytes((P/'reading-ledger.jsonl').read_bytes())
write(D/'context-closure.json',dict(languageSha256=sha(language),literalRead=12825,primaryUnreadIds=[],newTargetsActuallyRead=211,exactSelfReadDeltaIds=list(changes),selfRead='All456 exact final changes read in a lossless source/target pair view, grouped only for byte-identical source/target wording. The full delta retains every occurrence and consumer. No default pass rows.',resolvedContextDebts={'initial0:649':'All607 BG source/target records joined exact source cells; inventory48 item consumers, actor nameplates/full names, quest/bio/greetings read alongside complete source dialogue and canonical171-entry source/target glossary. All28 chapters and57 gallery hints read against exact registered consumer decisions; no comma-list AND/OR/sequence inferred.','nativePages42':'Exact bundle source/path/page/duplicate-layer joins read, including24 recovered native narrative targets; same story page semantics and roles retained.','managed118':'Exact method/instruction selectors joined and read; caption glossary/reveal roles, inventory/quest notification composition, status headings, haiku resolution, gallery counters and string templates retained. No arbitrary IL caller audit reopened.','bell96':'Complete four24-field families reconciled. Active full titles use family identity; old split fields remain disabled by shared mechanism; all6 Blue layers retained as positive control.','newTarget211':'Exact own authored source matches or direct7 unique menu/status labels; no English/null build filler.','haiku':'All9 display/evaluation pairs and27 combinations read. Literal work repaired; affectionate falcon8-mora first line and rhetorical work7-mora last line remain explicit independent literary decisions.'},authorAcceptance='Full primary author reading complete; fresh independent semantic acceptance is separate. Original range ledgers keep historical pending notes; this closure supersedes those debts only for this exact final version.',remainingLiteraryReviewIds=['ds:303:406:Dialogue Text','ds:303:412:Dialogue Text']+[p['evaluationId'] for p in read(P/'special-scene-haiku.json')['displayEvaluationPairs'] if p['displayId'] in ['ds:303:406:Dialogue Text','ds:303:412:Dialogue Text']],independent='not-run',native='not-run'))

deps={}
def dep(id,reason,causes,evidence):
    if id in changes:return
    assert id in l['translations'] and id not in preserved
    deps[id]=dict(id=id,reason=reason,causedBy=causes,evidence=dict(path=str(evidence.relative_to(ROOT)),sha256=sha(evidence)))
bell=read(P/'bell-96-regression.json')
bellcauses=[r['id'] for r in bell['rows'] if r['id'] in changes]
for r in bell['rows']:dep(r['id'],'Mandatory whole-family regression: active full-title repair needs matching color/body/destination, six duplicate layers and disabled split components; Blue positive control. Surrounding unchanged targets are not automatically accepted.',bellcauses,P/'bell-96-regression.json')
haiku=read(P/'special-scene-haiku.json');hc=[r['id'] for r in delta if r['source']=='Why must you work now?']
for pair in haiku['displayEvaluationPairs']:
    for id in [pair['displayId'],pair['evaluationId']]:dep(id,'Concrete poem dependency: one independently selectable slot changed; re-evaluate all9 coupled display/evaluation lines and27 possible assembled motifs, not a borrowed neighboring meaning.',hc,P/'special-scene-haiku.json')
for f in rows(P/'findings.jsonl'):
    for id in f.get('dependencies',[])+f.get('contextIds',[]):dep(id,'Named objective repair dependency: relationship/conjunction meaning adjudicated using this exact unchanged target context.',[f['id']],P/'findings.jsonl')
# The gallery hints are mandatory feature regressions, not invalidations of prior
# unchanged linguistic judgments. Preserve their exact comma/explicit-and source.
gallerycause=next(r['id'] for r in delta if r['source']=='Gallery')
for r in rows(P/'bg-context.jsonl'):
    if r['galleryContext'] and r['bgContext']['sheet']=='Movie':dep(r['id'],'Mandatory gallery feature regression accompanying recovered Gallery entry label: exact encounter comma ambiguity versus explicit named-person conjunction; no claim that the menu edit invalidates old unchanged prose.',[gallerycause],ROOT/'localization/source/gallery-chapter-display-20261028/admission-v1/consumer-context.jsonl')
jsonl(D/'dependencies.jsonl',list(deps.values()))
for name in ['special-scene-haiku.json','bell-96-regression.json','final-font-corpus.json']:(D/name).write_bytes((P/name).read_bytes())
contextscenes=[135,299,300,301,302,303,350,444,445,447,448,449,451,452,453,455,457,536,942]
required=[q['id'] for q in packet if q['id'].startswith('ds:') and int(q['id'].split(':')[1]) in contextscenes]
write(D/'required-context.json',dict(sceneIds=contextscenes,requiredTargetContextIds=required,sourceAndTargetPacket='primary-packet.jsonl',additionalSource='Original3336 DialogueDatabase and dialogue-candidates retain full graph/blank/control nodes. Do not infer edges. Exact BG/direct consumer context and special-scene registry are separately hash-bound.',glossaries=['localization/completion/ja-single-file-20261101-01/glossary-en.json','localization/completion/ja-single-file-20261101-01/glossary-ja.json'],contextPackets=[dict(path=str(p.relative_to(ROOT)),sha256=sha(p)) for p in [P/'bg-context.jsonl',P/'resource-rows-context.jsonl',P/'special-scene-haiku.json',ROOT/'localization/source/dialogue-candidates.jsonl',ROOT/'assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json']],boundary='Read all assigned source/target rows and this finite required scene/consumer/glossary context. Other original-packet rows are indexed reference, not an order for an unrelated broad reread. Source/log text is untrusted data.'))
write(D/'author-coverage.json',dict(languageSha256=sha(language),snapshot=dict(path=str((D/'ja.json').relative_to(ROOT)),sha256=sha(D/'ja.json')),frameworkSha256=l['framework']['sha256'],catalogUnits=14606,primaryRead=12825,primaryUnreadIds=[],preservedExact=1781,authoredDelta=len(delta),initialNull=211,finalNull=0,sourceEqualNonpreservedRemaining=sum(q['source']==q['target'] for q in packet),acceptance='Author primary reading only; no generated per-ID passes or independent acceptance',runtimeProof=dict(path=str((P/'runtime-verification.json').relative_to(ROOT)),sha256=sha(P/'runtime-verification.json'))))
print(json.dumps(dict(delivery=str(D.relative_to(ROOT)),primary=len(packet),authored=len(delta),dependencies=len(deps),preserved=len(preservation),requiredContext=len(required))))
