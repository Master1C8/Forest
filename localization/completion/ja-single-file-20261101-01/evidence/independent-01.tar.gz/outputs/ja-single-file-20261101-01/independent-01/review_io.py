import json, sys, hashlib
from pathlib import Path

ROOT = Path('/Users/antonkrutov/Desktop/Forest')
PHASE = ROOT / 'outputs/ja-single-file-20261101-01/independent-01'
PACKET = ROOT / 'localization/editorial-delivery/ja-single-file-20261101-01/independent-scope/review-packet.jsonl'
CONTEXT = PHASE / 'required-context.jsonl'

def rows(kind):
    return [json.loads(x) for x in (PACKET if kind == 'p' else CONTEXT).read_text().splitlines()]

def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()

if sys.argv[1] == 'groups':
    groups = {}
    for i, r in enumerate(rows('p')):
        groups.setdefault((r['source'],r['target']), []).append(i)
    groups = list(groups.items())
    for g in range(int(sys.argv[2]), int(sys.argv[3])):
        (source,target), indexes = groups[g]
        print('G',g,'p',','.join(map(str,indexes)))
        print(json.dumps([source,target],ensure_ascii=False,separators=(',',':')))
        for i in indexes:
            r=rows('p')[i]; c=r.get('context',{})
            if 'actorId' in c:
                print(i,r['id'],json.dumps([c['conversation'],c['actorId'],c['conversantId'],c['conditions'],c['script'],c['next']],ensure_ascii=False,separators=(',',':')))
            for s in c.get('selectors',[]):
                if s.get('kind') not in ['field','bg']:
                    print(i,json.dumps(s,ensure_ascii=False,separators=(',',':')))
            for u in r.get('consumerContext',[]):
                print(i,json.dumps([u['hierarchy'],u['componentEnabled'],u['classification']],ensure_ascii=False,separators=(',',':')))
                if u['value']!=source: print('U-value',json.dumps(u['value'],ensure_ascii=False))
elif sys.argv[1] == 'context':
    primary={(r['source'],r['target']):i for i,r in enumerate(rows('p'))}
    prev=None
    for i in range(int(sys.argv[2]),int(sys.argv[3])):
        r=rows('c')[i]; c=r['context']
        if c['conversation']!=prev:
            print('SCENE',c['conversation']);prev=c['conversation']
        print('c'+str(i),r['id'],c['actorId']+'>'+c['conversantId'],'next='+str(c['next']))
        pair=(r['source'],r['target'])
        if pair in primary: print('WORDING=p'+str(primary[pair]))
        else: print(json.dumps(pair,ensure_ascii=False,separators=(',',':')))
        if c['conditions'] or c['script']:print('STATE',json.dumps([c['conditions'],c['script']],ensure_ascii=False))
elif sys.argv[1] == 'read':
    kind, start, end = sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
    data = rows(kind)
    for i in range(start, end):
        r = data[i]
        rid = r['id']
        if rid.startswith('StreamingAssets/'):
            rid = 'bundle:' + rid.split(':', 1)[1]
        elif rid.startswith('bgdb:'):
            rid = 'bg:' + rid.split('/row/', 1)[1]
        print(f'{kind}{i} {rid}')
        print(json.dumps([r['source'], r['target']], ensure_ascii=False, separators=(',', ':')))
        c = r.get('context', {})
        if 'actorId' in c:
            print('C', json.dumps([c['conversation'],c['actorId'],c['conversantId'],c['conditions'],c['script'],c['next']], ensure_ascii=False, separators=(',', ':')))
        else:
            for s in c.get('selectors', []):
                if s.get('kind') not in ['field','bg']:
                    print('C', json.dumps(s, ensure_ascii=False, separators=(',', ':')))
        for c in r.get('consumerContext', []):
            print('U', json.dumps([c['class'],c['classification'],c['componentEnabled'],c['hierarchy']], ensure_ascii=False, separators=(',', ':')))
            if c['value'] != r['source']:
                print('U-value', json.dumps(c['value'],ensure_ascii=False))
elif sys.argv[1] == 'attach-groups':
    data=rows('p'); groups={}
    for i,r in enumerate(data): groups.setdefault((r['source'],r['target']),[]).append(i)
    groups=list(groups.values()); authored=PHASE/sys.argv[2]; out=[]; seen=set()
    for line in authored.read_text().splitlines():
        if not line.strip():continue
        index,verdict,rationale=line.split('\t'); g=int(index)
        assert g not in seen;seen.add(g)
        for i in groups[g]:
            r=data[i]
            assert sha(r['source'])==r['sourceSha256'] and sha(r['target'])==r['targetSha256']
            out.append(dict(id=r['id'],verdict=verdict,rationale=rationale,
                            sourceSha256=r['sourceSha256'],targetSha256=r['targetSha256'],
                            authoredJudgmentGroup=g,packetOrdinal=i))
    assert seen==set(range(187)), 'Every group needs an explicit authored judgment'
    assert len(out)==607
    out.sort(key=lambda j:j['packetOrdinal'])
    dest=PHASE/'judgments.jsonl';assert not dest.exists()
    dest.write_text(''.join(json.dumps(j,ensure_ascii=False)+'\n' for j in out))
    print(json.dumps({'explicitAuthoredGroups':len(seen),'versionBoundJudgments':len(out)}))
elif sys.argv[1] == 'attach':
    data = rows('p')
    authored = PHASE / sys.argv[2]
    out = []
    for line in authored.read_text().splitlines():
        if not line.strip():
            continue
        index, verdict, rationale, *proposal = line.split('\t')
        r = data[int(index)]
        assert sha(r['source']) == r['sourceSha256']
        assert sha(r['target']) == r['targetSha256']
        j = dict(id=r['id'], verdict=verdict, rationale=rationale,
                 sourceSha256=r['sourceSha256'], targetSha256=r['targetSha256'])
        if proposal:
            j['proposedTarget'] = json.loads(proposal[0])
        out.append(j)
    dest = PHASE / 'judgments.jsonl'
    existing = [json.loads(x) for x in dest.read_text().splitlines()] if dest.exists() else []
    ids = [r['id'] for r in existing + out]
    assert len(ids) == len(set(ids)), 'duplicate judgment'
    with dest.open('a') as f:
        for j in out:
            f.write(json.dumps(j, ensure_ascii=False) + '\n')
    print(json.dumps({'attached': len(out), 'total': len(ids)}))
