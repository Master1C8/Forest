import json, hashlib, itertools
from pathlib import Path
from datetime import datetime, timezone

ROOT=Path('/Users/antonkrutov/Desktop/Forest')
P=ROOT/'outputs/ja-single-file-20261101-01/independent-01'
D=ROOT/'localization/editorial-delivery/ja-single-file-20261101-01'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
tsha=lambda s:hashlib.sha256(s.encode()).hexdigest()
def save(name,data):
    q=P/name
    assert not q.exists(),str(q)
    q.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
def jsonl(name,rows):
    q=P/name;assert not q.exists()
    q.write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))

runtime=json.loads((P/'runtime-verification.json').read_text())
identity=runtime['actualRuntime'];assert identity['turn']=={'model':'gpt-6.1-sol','effort':'high'}
assert identity['session']['model_provider']=='openai' and identity['session']['parent_thread_id'] is None
lang=json.loads((D/'ja.json').read_text())['translations']
packet=[json.loads(l) for l in (D/'independent-scope/review-packet.jsonl').read_text().splitlines()]
context=[json.loads(l) for l in (P/'required-context.jsonl').read_text().splitlines()]
judgments=[json.loads(l) for l in (P/'judgments.jsonl').read_text().splitlines()]
assert len(judgments)==607 and len({r['id'] for r in judgments})==607
assert {r['id'] for r in judgments}=={r['id'] for r in packet}
for r in packet+context:
    assert lang[r['id']]=={'source':r['source'],'target':r['target']}
    assert tsha(r['source'])==r['sourceSha256'] and tsha(r['target'])==r['targetSha256']

batches=[
(0,90,'Complete friendship reconciliation135 and second encounter299; retained explicit no-romantic-reunion statement and gratitude/sexual-history distinctions.'),
(90,180,'Quoted sexual verse300, full301,302 and beginning303; read poems, replies, addressees and distinct metaphor/sexual-role facts.'),
(180,280,'Remainder of full303 wording, haiku definition, all choice slots and feedback; glowing stones350, fantasy444 and repeated cave-peek445.'),
(280,400,'Complete solo fluids447, knot448, anal449 and Maverick451 narratives, plus excursion gossip452; read roles, numbers, modality and staging context.'),
(400,520,'Remaining452 and first excursion453 exchanges; speaker labels already read in primary reused by exact source/target pair while each graph binding remained visible.'),
(520,650,'Remaining453 including all Marygold/Becka exchanges and beginning455 group-bear scene; checked role assignments, numerical/physical and consent/context distinctions.'),
(650,780,'Remaining455 and first457 bear follow-up exchanges; checked speaker-specific labels and physical position versus sexual-role uses.'),
(780,845,'Remainder457 and full required536/942 quest-introduction context; retained definite Charlotte/Melody pair and identified942:808 first-dibs difference.')]
ledger=[]
for a,b,note in batches:
 for i in range(a,b):
  r=context[i]
  ledger.append(dict(id=r['id'],contextOrdinal=i,sourceSha256=r['sourceSha256'],targetSha256=r['targetSha256'],readingStatus='read',readingBatch=[a,b],batchObservation=note,semanticAcceptance='Context reading only; no primary coverage or default semantic verdict',reviewerThreadId=runtime['threadId']))
assert len(ledger)==845
jsonl('context-reading-ledger.jsonl',ledger)

pres=json.loads((ROOT/'localization/completion/ja-single-file-20261101-01/source-preservation.json').read_text())
assert len(pres['baselinePreserved'])==1781
for ident,h in pres['baselinePreserved'].items():
 r=lang[ident];assert r['source']==r['target'] and tsha(r['source'])==h
save('deterministic-evidence.json',dict(languageSha256=sha(D/'ja.json'),primaryRows=607,contextRows=845,allRowsMatchFrozenLanguage=True,allTextHashesMatch=True,sourcePolicyValuesChecked=1781,sourcePolicyMismatches=[],sourcePolicyMeaning='Exact byte preservation only, no new source classification or linguistic acceptance',primaryWordingGroups=187,groupJudgmentsSource='authored-group-judgments.tsv',defaultJudgmentsGenerated=False,semanticJudgments='Authored by the actual reviewer after reading each wording and every required occurrence/context; script only transfers exact group decisions',boundaries=['No compiler/build/game/native execution','Existing16-resource/8-face/247-member/1385-texture evidence is historical version-bound static evidence, not new acceptance','Font439/TMP1017 mismatch remains open']))

pairs=json.loads((D/'special-scene-haiku.json').read_text())['displayEvaluationPairs']
verbal={325:'Changing/molding the ground, first-person speaker supplied by source scene; natural five-mora bridge opening.',326:'Crossing raging water; seven mora, retaining movement and force.',327:'Uniting friends; five mora, coherent bridge purpose.',406:'Affectionate falcon address retained, but eight mora in a first slot described as five. Not accepted as a documented exception.',407:'Request to be taken beyond/above clouds; seven mora without naming Penny.',408:'Unvisited place; five mora without an early named referent.',410:'Busy little insect; five mora. Its activity does not authorize dropping work from an independently selected final slot.',411:'Question of what matters to the addressee; seven mora and no predetermined answer.',412:'Now/why/work remain in archaic compressed wording, but seven mora and necessity is only pragmatic; a strict five-mora replacement preserving all independent facts is unresolved.'}
choices=[]
for r in pairs:
 node=int(r['displayId'].split(':')[2]);choices.append(dict(**r,verdict='finding' if node in [406,412] else 'pass',rationale=verbal[node],safeStrictMeterReplacement=None if node in [406,412] else r['target']))
# Every combination below is an authored model judgment, not a default pass derived from meter.
combo_text='''325,326,327|pass|The complete bridge poem naturally joins shaped ground, raging water and friends;5-7-5 and the good bridge response agree.
325,326,408|pass|The ground/water/unvisited-place mix keeps each independently chosen meaning and source mixed outcome;5-7-5 survives despite partial semantic coherence.
325,326,412|finding|Ground and raging water remain source-faithful; the independent now/why/work final line is seven mora, so this mixed choice requires the412 repair.
325,407,327|pass|Ground, cloudward transport and uniting friends remain three distinct selectable ideas;5-7-5 preserves the intentional mixed outcome.
325,407,408|pass|Ground, cloudward transport and an unvisited place remain source-faithful; the partly coherent mixed composition is still5-7-5, not silently converted to Penny success.
325,407,412|finding|The ground/cloud/work mix retains each topic but the final412 line remains seven mora; no work fact may be borrowed from the absent bug opening.
325,411,327|pass|The ground/value-question/friends mix retains all three meanings and5-7-5; the intentional mixed evaluation remains appropriate.
325,411,408|pass|Ground, values and unvisited place retain independent meanings and5-7-5; no new link is invented to make this a coherent accepted family.
325,411,412|finding|The ground/value/work mix retains the question but exposes412's seven-mora final slot and implicit necessity; it needs the same final-line repair.
406,326,327|finding|Affectionate falcon, raging water and friends remain distinct; the first slot is eight mora and invalidates this mixed composition's strict meter.
406,326,408|finding|Falcon/water/unvisited-place keeps the source mix but starts with eight mora; shortening it to a bare falcon would lose affection.
406,326,412|finding|The falcon/water/work mix exposes both the eight-mora first slot and seven-mora last slot; neither surrounding line can supply the lost facts of a shortened repair.
406,407,327|finding|Falcon/cloud/friends retains the source mixture but the affectionate falcon opening is eight mora; friends must not be changed to force Penny-theme success.
406,407,408|finding|The coherent Penny poem retains affection, falcon, cloudward transport and the unvisited destination, but8-7-5 contradicts the taught form while receiving good feedback430-435.
406,407,412|finding|Falcon/cloud/work retains the source mixed ideas; both406 and412 violate their five-mora slots, and work must stand independently of a bug opening.
406,411,327|finding|Falcon/value/friends remains a mixed composition with an eight-mora opening; no affection may be transferred to the question or friends line.
406,411,408|finding|Falcon/value/unvisited-place retains every slot meaning and mixed outcome, but406 still makes the first line eight mora.
406,411,412|finding|Falcon/value/work retains all independent topics but both first and last slots need literary repair; the value question supplies neither falcon affection nor work necessity.
410,326,327|pass|Busy insect, raging water and friends remain the intentional source mixture;5-7-5 is retained without imposing new causal links.
410,326,408|pass|Busy insect, raging water and unvisited place remain independent source ideas with5-7-5 and the mixed outcome.
410,326,412|finding|The insect/water/work mix remains understandable, but412 is seven mora and must retain now/why/work/necessity within its own slot.
410,407,327|pass|Busy insect, cloudward transport and friends preserve the source mix and5-7-5; no new good-family interpretation is introduced.
410,407,408|pass|Busy insect, cloudward transport and unvisited place retain the intentionally mixed identity despite semantic continuity in the latter two lines;5-7-5 survives.
410,407,412|finding|Insect/cloud/work retains the mixed theme but412 still overruns the last slot; its work meaning must not depend on the insect opening.
410,411,327|pass|Busy insect, the value question and friends retain independent meanings and5-7-5; a coherent moral is not invented to change the mixed outcome.
410,411,408|pass|Busy insect, the value question and unvisited place preserve the source mix and5-7-5 without supplying a new answer to the question.
410,411,412|finding|The coherent bug poem retains the critique of busyness and its rhetorical question, but5-7-7 leaves the final slot inconsistent with the form while receiving good feedback438-443.'''
combinations=[]
lookup={int(r['displayId'].split(':')[2]):r for r in pairs}
for line in combo_text.splitlines():
 nodes,verdict,rationale=line.split('|');nodes=list(map(int,nodes.split(',')))
 combinations.append(dict(nodes=nodes,source=[lookup[n]['source'] for n in nodes],target=[lookup[n]['target'] for n in nodes],mora=[lookup[n]['mora'] for n in nodes],verdict=verdict,rationale=rationale,sourceOutcome='bridge_ending' if nodes==[325,326,327] else 'penny_ending' if nodes==[406,407,408] else 'bug_ending' if nodes==[410,411,412] else 'mixed_ending'))
assert len(combinations)==27 and {tuple(r['nodes']) for r in combinations}==set(itertools.product([325,406,410],[326,407,411],[327,408,412]))
save('literary-review.json',dict(languageSha256=sha(D/'ja.json'),status='findings; not a clean literary acceptance',definitionEvidence=['ds:303:392:Dialogue Text','ds:303:393:Dialogue Text','ds:303:370:Dialogue Text','ds:303:371:Dialogue Text','ds:303:383:Dialogue Text'],definitionJudgment='The scene teaches5-7-5 and says form is only one part of haiku. Japanese haiku can use deliberate excess mora, but that general possibility does not make these large selectable-slot overruns an accepted, source-bound adaptation. No gameplay-meter rejection is invented: source outcome selection is thematic, separately mapped.',choices=choices,combinations=combinations,combinationCounts=dict(passCount=12,findingCount=15,coherentBridge='pass',coherentPenny='finding',coherentBug='finding',mixedSourceOutcomes=24),repairDecision=dict(status='needs literary adjudication; no complete safe strict5-7-5 correction claimed',wholeFamilySemanticCandidates=[dict(family='Penny',lines=['愛しのハヤブサ','雲越え連れて','未踏の地'],readings=['いとしのはやぶさ','くもこえつれて','みとうのち'],mora=[8,7,5],use='Complete usable meaning-preserving family, already represented in current text; NOT a strict-meter repair or approval.'),dict(family='bug',lines=['小虫急く','何が大事か','今、なぜ働かねばならぬ'],readings=['こむしせく','なにがだいじか','いまなぜはたらかねばならぬ'],mora=[5,7,13],use='Complete usable semantic candidate makes now/why/work/necessity explicit; NOT accepted for application because final meter remains unresolved.')],rejectedShortcuts=[dict(target='ハヤブサよ',reading='はやぶさよ',mora=5,reason='Bare falcon vocative loses lovely/affection; cannot borrow it from cloud or destination slots.'),dict(target='今せねば',reading='いませねば',mora=5,reason='Must do now loses explicit work and why; the bug opening is independently replaceable.'),dict(target='働くな',reading='はたらくな',mora=5,reason='Imperative do not work changes the rhetorical question and loses now/why/necessity.')],nextAction='Adjudicate both families together. A safe strict-meter solution is not supplied by this review; do not apply a knowingly lossy shortcut. Keep review debt until an actual source-faithful complete adaptation is independently checked.'),dependencies=dict(displayEvaluationIds=[r[k] for r in pairs for k in ['displayId','evaluationId']],changedFamilies=['ds:303:406:Dialogue Text','ds:303:412:Dialogue Text'],fullSceneContext='All required303 wording plus every original blank/control graph node read; graph nodes bind actual selection/revision/submission and branch destinations.',choiceMenuNodes=[419,599,600],lineCallbacks=[425,426,427],confirmationAndEditNodes=[416,597,417,418,420,421],submitNodes=[598,422,423],endingRouter=129,endingNodes=[320,466,467,468],feedbackIds=[f'ds:303:{n}:Dialogue Text' for n in [430,431,433,435,438,439,441,443,446,447,449,450,451,453,460,461,463,465]],relatedPoemAndQuoteIds=[f'ds:{s}:{n}:Dialogue Text' for s,n in [(300,483),(300,484),(302,504),(302,516),(302,520),(302,559),(302,580),(302,581),(303,330),(303,343),(303,350),(303,376)]],quoteBoundary='No extra fixed quotation of406/412 was found in the frozen single-file inventory; dynamic selected-line display, exact paired labels and all27 compositions remain dependent. Feedback must retain the original intended good/mixed outcomes; do not rewrite praise merely to conceal bad target meter.'),runtime='not-run; structural display/evaluation identity is not literary or gameplay acceptance'))

observations=[
 dict(id='ds:942:808:Dialogue Text',verdict='finding',rationale='Source promises Penny and Mabel first dibs on the newly cleared bench/encounter. 最優先で誘う instead promises to prioritize inviting them, weakening their promised first chance and leaving the promise recipient unstated. The exact backup536:808 and preceding bench context resolve the referent.',proposedTarget='[pic=7]ペニーとメイベルに、最初に使わせるって約束したの！',evidenceIds=['ds:536:806:Dialogue Text','ds:536:808:Dialogue Text','ds:942:807:Dialogue Text','ds:942:809:Dialogue Text']),
 dict(id='ds:135:369:Dialogue Text',verdict='needs-review',rationale='のろける conventionally suggests talking proudly about a lover/partner. The source mushy after bodily banter can support that teasing effect, but135:346 explicitly excludes renewed partnership. This is a bounded potential contextual implication, not a proven claim that the primary reconciliation repairs are wrong.',proposedTarget='[pic=5]ええと…こほん！ すみません、ラスカル…君の前で、こんなに感傷的になるつもりは…',evidenceIds=['ds:135:346:Dialogue Text','ds:135:361:Dialogue Text','ds:135:367:Dialogue Text']),
 dict(id='ds:139:182:Dialogue Text',verdict='needs-review',rationale='ライド＆スプーン retains the sound of the proposed name, but スプーン alone ordinarily denotes the utensil rather than spooning/cuddling. The English joke combines transport and intimate services; no supplied line explains that sense of Spoon. Check whether the deliberately bad Japanese business-name joke actually conveys the cuddling sense, without silently fixing the intentionally mocked rhyme.',proposedTarget='[pic=11]「ペニー・プルームのライド＆添い寝スプーン」は？ 「ペニー・プルームのライド＆おまんプーン」は？',proposalStatus='Candidate for source-bound adjudication, not accepted or applied',evidenceIds=['ds:139:152:Dialogue Text','ds:139:156:Dialogue Text','ds:139:157:Dialogue Text','ds:139:159:Dialogue Text','ds:139:177:Dialogue Text','ds:139:180:Dialogue Text','ds:139:183:Dialogue Text'])]
for r in observations:
 t=lang[r['id']];r.update(source=t['source'],target=t['target'],sourceSha256=tsha(t['source']),targetSha256=tsha(t['target']),reviewerThreadId=runtime['threadId'],coverage='separate contextual observation; not one of607 primary judgments')
jsonl('context-observations.jsonl',observations)

save('review-summary.json',dict(game='The Forest of Love',gameVersion='0.45',locale='ja',culture='ja-JP',stage='editorial',framework='forest045-shared-v2',languageSha256=sha(D/'ja.json'),primary=dict(assigned=607,read=607,judged=607,passCount=603,findingCount=4,unreadIds=[],findingIds=[r['id'] for r in judgments if r['verdict']=='finding'],wordingGroups=187),context=dict(required=845,actuallyRead=845,contractsRead=True,ledger='context-reading-ledger.jsonl',observations='context-observations.jsonl',observationCounts=dict(finding=1,needsReview=2),additionalSourceRegressionReading='Source-only reference rows were joined by exact ID/source to the frozen Japanese snapshot for keyboard/input, sexual-role/physical position/dominance, business/transport/cuddling and former-roommate facts. They are context observations, not fabricated whole-corpus independent coverage.'),literary=dict(choicesRead=9,compositionsRead=27,strictMeterFindings=15,evidence='literary-review.json',status='not clean'),runtimeVerification=dict(threadId=runtime['threadId'],model='gpt-6.1-sol',reasoning='high',provider='openai',parentThreadId=None,freshExec=True,metadataCheckedBeforeLocalizedInput=True),inputBindings=[dict(path=str(f.relative_to(ROOT)),sha256=sha(f)) for f in [D/'manifest.json',D/'context-closure.json',D/'ja.json',D/'independent-scope/review-packet.jsonl',P/'required-context.jsonl',D/'required-context.json',ROOT/'localization/completion/ja-single-file-20261101-01/glossary-en.json',ROOT/'localization/completion/ja-single-file-20261101-01/glossary-ja.json']],remainingGates=['Consolidated literary adjudication and exact independent correction delta','Separate context findings/adjudication and their exact reproducible dependency closure','Parent-owned selected Font439/dependent TMP1017 metrics repair','Native CFF/font/fallback/atlas/layout/game behavior not run','Human NSFW glossary review remains owner-deferred','No installer/publication/deployment/release acceptance'],completion='Finite assigned independent review complete with findings; Japanese localization is not accepted as finished',nextTask='Existing pinned next-task.json; parent adjudicates findings and font repair. No automatic nested model/queue follows.'))

# Actual deterministic joins only; no runtime claim.
fmt=lang[next(r['id'] for r in packet if r['source']=='More critters {0}{1}{2}{3}{4}.')]['target']
fragments=['北, ','南, ','西, ','中央の森, ','止まり場, ']
joins=[]
for flags in itertools.product([False,True],repeat=5):
 value=fmt.format(*[text if keep else '' for text,keep in zip(fragments,flags)]).replace(', .','.')
 joins.append(dict(included=list(flags),assembled=value))
save('regression-evidence.json',dict(languageSha256=sha(D/'ja.json'),bell96=dict(reviewed=96,families=4,layersPerField=6,activeFullTitle='24 fullTitle(2) rows match family/body destinations; source BLUE clones explicitly contextualized',legacySplit='48 first-character/suffix rows match; disabling is retained static evidence, not a new native observation',body='24 body rows read; Blue unknown-use invitation retained',source='bell-96-regression.json and exact primary consumer bindings'),inventory12='All twelve heading layers read across size22 and30; same 持ち物 wording',gallery='All57 assigned gallery hints read with exact Movie row/consumer contracts; comma lists retain ambiguity and named conjunctions retain joint groups',controls='1781 exact source-policy values verified against frozen snapshot; original commands/fictional strings unchanged',questJoin=dict(contractPath='localization/fonts/locale-completion-20261030/quest-history-slot-flow-v1/revision02/flow-context.json',contractSha256=sha(ROOT/'localization/fonts/locale-completion-20261030/quest-history-slot-flow-v1/revision02/flow-context.json'),predicate='All32 literal inclusion combinations assembled using source Format and exact Replace(", .", ".") contract; branch reachability/native display not tested. Zero-inclusion source quirk remains a quirk, not a fabricated grammatical sentence.',assemblies=joins),otherContext='Physical position versus insertive/receptive roles and dominance read in actual571/577/950 and source-context families; keyboard labels/OR retained; business/transport/cuddling checked with separate139:182 needs-review observation',font='Static payload/readback evidence retained; TMP1017 coherence and native loading are not accepted',exhaustiveness='607 assigned primary versions plus845 required context rows only; no new full14606-entry independent semantic coverage'))

config=json.loads((P/'task.json').read_text());bad=[]
for f,h in config['job']['immutablePins'].items():
 if sha(ROOT/f)!=h:bad.append(f)
assert not bad,bad
save('pin-verification.json',dict(checked=len(config['job']['immutablePins']),mismatches=bad,checkedAtUtc=datetime.now(timezone.utc).isoformat(),scope='All task immutablePins before review and after evidence writing; source/current Japanese/helpers/frozen instructions unchanged'))
print(json.dumps(dict(primaryJudgments=607,primaryPass=603,primaryFinding=4,contextRead=845,contextFinding=1,contextNeedsReview=2,haikuCombinations=27,haikuCombinationFindings=15,pinsVerified=138)))
