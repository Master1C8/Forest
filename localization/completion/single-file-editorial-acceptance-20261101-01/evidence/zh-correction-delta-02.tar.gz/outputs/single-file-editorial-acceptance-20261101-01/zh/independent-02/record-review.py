"""Bind explicitly authored judgments and completed context reading to exact inputs.

No model calls, target edits, generated semantic verdicts, or queue execution.
"""
import copy
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/antonkrutov/Desktop/Forest')
PHASE = Path(__file__).resolve().parent
REPAIR = ROOT / 'localization/editorial-delivery/zh-single-file-20261101-01/repair-02'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def rows(path):
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def write_new(name, data, jsonl=False):
    path = PHASE / name
    with path.open('x') as stream:
        if jsonl:
            for row in data:
                stream.write(json.dumps(row, ensure_ascii=False) + '\n')
        else:
            stream.write(json.dumps(data, ensure_ascii=False, indent=2) + '\n')


task = read(PHASE / 'task.json')
for name, expected in task['job']['immutablePins'].items():
    assert sha(ROOT / name) == expected, name
runtime = read(PHASE / 'runtime-verification.json')
actual = runtime['actualRuntime']
assert actual['session']['model_provider'] == 'openai'
assert actual['session']['parent_thread_id'] is None
assert actual['turn'] == {'model': 'gpt-6.1-sol', 'effort': 'high'}
assert runtime['freshExecNoResumeNoFork'] is True
packet = rows(ROOT / task['task']['reviewPacket'])
context = rows(REPAIR / 'complete-bell-context.jsonl')
authored = rows(PHASE / 'authored-verdicts.jsonl')
assert len(packet) == len(authored) == 36
assert len(context) == 96
by_id = {r['id']: r for r in packet}
context_by_id = {r['id']: r for r in context}
assert len(by_id) == 36 and len(context_by_id) == 96
assert set(by_id) <= set(context_by_id)
judgments = []
for judgment in authored:
    ident = f"sharedassets2.assets:{judgment['pathId']}/m_text"
    assigned = by_id[ident]
    assert judgment['verdict'] == 'pass' and judgment['rationale']
    judgments.append(dict(id=ident, verdict=judgment['verdict'],
        rationale=judgment['rationale'], reviewed=True,
        sourceSha256=assigned['sourceSha256'], targetSha256=assigned['targetSha256']))
assert len({r['id'] for r in judgments}) == 36
assert {r['id'] for r in judgments} == set(by_id)

before = read(REPAIR / 'language-before.json')
current = read(ROOT / 'localization/languages/zh.json')
assert current == read(REPAIR / 'language-reviewed.json')
changed = {ident for ident in current['translations']
           if current['translations'][ident] != before['translations'][ident]}
corrections = rows(REPAIR / 'authored-corrections.jsonl')
assert len(changed) == 18 and changed == {r['id'] for r in corrections}
normalized = copy.deepcopy(current)
for ident in changed:
    assert current['translations'][ident]['source'] == before['translations'][ident]['source']
    normalized['translations'][ident]['target'] = before['translations'][ident]['target']
assert normalized == before, 'Changes outside the exact eighteen target fields'
assert set(''.join(v['target'] for v in current['translations'].values())) == set(
    ''.join(v['target'] for v in before['translations'].values()))
policy = read(REPAIR / 'closure-policy.json')['components']
assert len(policy['currentClosure']) == 1730
assert len(policy['previousClosure']) == 1712
assert len(policy['completeFourBellFamily']) == 96
assert set(policy['corrected']) == changed
assert set(policy['currentClosure']) - set(policy['previousClosure']) == set(policy['addedDependencies'])
assert len(policy['addedDependencies']) == 18 and not policy['removedDependencies']
assert set(policy['exactDelta']) == changed | set(policy['addedDependencies']) == set(by_id)

for row in context:
    assert current['translations'][row['id']]['source'] == row['source']
    assert current['translations'][row['id']]['target'] == row['target']
    for field in ['source', 'target']:
        assert hashlib.sha256(row[field].encode()).hexdigest() == row[field + 'Sha256']
    assert row['originalSourceContext']['value'] == row['source']
    if row['id'] in by_id:
        assert all(row[k] == by_id[row['id']][k] for k in ['source', 'target', 'sourceSha256', 'targetSha256', 'selectors'])

saved = read(REPAIR / 'saved-resource-readback.json')
manifest_path = ROOT / saved['artifact']['path']
assert sha(manifest_path) == saved['artifact']['sha256']
manifest = read(manifest_path)
assert manifest['languageSha256'] == sha(ROOT / 'localization/languages/zh.json')
assert len(manifest['files']) == saved['verifiedResourceCount'] == 16
for name, binding in manifest['files'].items():
    path = manifest_path.parent / name
    assert path.stat().st_size == binding['bytes'] and sha(path) == binding['sha256'], name
for family in saved['families']:
    assert family['activation'] == {'Title (1)': False, 'Title': False, 'Title (2)': True}
    assert len(family['layers']) == 6
    for layer in family['layers']:
        c = context_by_id[layer['id']]
        assert layer['text'] == c['target']
        assert c['effectiveBinding']['color'] == family['color']
        assert c['effectiveBinding']['activeTitleGameObject'] == family['activeTitleGameObject']

write_new('judgments.jsonl', judgments, jsonl=True)
write_new('context-reading.jsonl', [dict(
    id=r['id'], sourceSha256=r['sourceSha256'], targetSha256=r['targetSha256'],
    contextRowSha256=hashlib.sha256(json.dumps(r, ensure_ascii=False, sort_keys=True,
        separators=(',', ':')).encode()).hexdigest(),
    contextRowHashRepresentation='UTF-8 sorted-key compact JSON, ensure_ascii=False, no trailing newline',
    contextPacket='localization/editorial-delivery/zh-single-file-20261101-01/repair-02/complete-bell-context.jsonl',
    contextPacketSha256=sha(REPAIR / 'complete-bell-context.jsonl'),
    read=True, readFields=['source', 'target', 'selectors', 'originalSourceContext.value',
        'originalSourceContext.hierarchy', 'originalSourceContext.class',
        'originalSourceContext.classification', 'originalSourceContext.reviewGroup',
        'originalSourceContext.componentEnabled', 'originalSourceContext.ancestors', 'effectiveBinding'],
    reviewerThreadId=runtime['threadId'], notAdditionalPrimaryCoverage=True,
    targetEdited=False) for r in context], jsonl=True)
write_new('input-verification.json', dict(
    runtime=runtime, actualSessionAndTurnMetadataIndependentlyRead=True,
    liveProcessArgvIndependentlyReadBeforeLocalizedInput=True,
    immutablePinsVerified=len(task['job']['immutablePins']), immutablePinMismatches=[],
    immutablePins=task['job']['immutablePins'],
    taskSha256=sha(PHASE / 'task.json'),
    exactDeltaVerified=dict(corrected=18, addedBlueDependencies=18, assigned=36,
        previousClosure=1712, currentClosure=1730, completeBellContext=96),
    sourceAllFieldsAndControlsUnchanged=True, otherTargetsAndFontLayoutFrameworkFieldsUnchanged=True,
    targetCharacterSetExactlyUnchanged=True, artifact=saved['artifact'],
    compiledResourceFilesVerifiedBySizeAndSha256=16,
    savedReadbackReceiptSha256=sha(REPAIR / 'saved-resource-readback.json'),
    activationAndSixLayerTitleCopiesMatchPinnedReadback=True,
    boundary='Hash/structure checks only; semantic verdicts are explicitly authored in authored-verdicts.jsonl. Existing saved-resource readback is reused on exact artifact hashes; no new binary decode or runtime test.'))
print(json.dumps(dict(judgmentsWritten=36, requiredContextRead=96,
    immutablePinsVerified=67, artifactFilesVerified=16, findings=0)))
