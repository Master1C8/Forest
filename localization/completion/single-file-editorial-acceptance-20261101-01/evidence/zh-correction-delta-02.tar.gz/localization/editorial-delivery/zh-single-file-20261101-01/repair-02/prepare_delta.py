"""Reproduce the finite four-bell closure and exact correction delta; no judgments."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path('/Users/antonkrutov/Desktop/Forest')
sys.path.insert(0, str(ROOT / 'tools'))
from locale_review_work import prepare_scope


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


def write_rows(path, rows):
    with path.open('x') as stream:
        for row in rows:
            stream.write(json.dumps(row, ensure_ascii=False) + '\n')


def main():
    here = Path(__file__).resolve().parent
    language = ROOT / 'localization/languages/zh.json'
    doc = read(language)
    catalog = read(ROOT / 'localization/framework/forest045-shared-v2/catalog.json')
    catalog_map = {r['id']: r for r in catalog}
    old_root = here.parent
    old_scope_path = old_root / 'independent-scope/scope.json'
    old_scope = read(old_scope_path)
    old_ids = set(old_scope['reviewIds'])
    original = ROOT / old_scope['originalPacket']['path']
    assert sha(original) == old_scope['originalPacket']['sha256']
    originals = {r['id']: r for r in map(json.loads, original.read_text().splitlines())}
    contract_path = ROOT / 'localization/hotfixes/ru-dates-titleflow-20261029/bell-layout-contract.json'
    contract = read(contract_path)
    families = {r['hierarchy']: r for r in contract['families']}
    source_path = ROOT / contract['sourceInventory']
    assert sha(source_path) == contract['sourceInventorySha256']
    source = [json.loads(line) for line in source_path.read_text().splitlines()]
    family_rows = [r for r in source if any(r.get('hierarchy', '').startswith(f + '/') for f in families)]
    assert len(family_rows) == len({r['id'] for r in family_rows}) == 96
    corrections = [json.loads(line) for line in (here / 'authored-corrections.jsonl').read_text().splitlines()]
    changed = {r['id'] for r in corrections}
    assert len(changed) == 18 and changed <= old_ids
    family_ids = {r['id'] for r in family_rows}
    current_ids = old_ids | family_ids
    added = current_ids - old_ids
    delta = changed | added
    assert len(current_ids) == 1730 and len(added) == 18 and len(delta) == 36
    packet = []
    contexts = []
    for row in catalog:
        ident = row['id']
        if ident not in current_ids:
            continue
        version = doc['translations'][ident]
        assert version['source'] == row['source']
        item = dict(originals.get(ident, dict(id=ident, selectors=catalog_map[ident]['selectors'])))
        item.update(source=version['source'], target=version['target'],
                    sourceSha256=hashlib.sha256(version['source'].encode()).hexdigest(),
                    targetSha256=hashlib.sha256(version['target'].encode()).hexdigest())
        packet.append(item)
    by_id = {r['id']: r for r in packet}
    for row in family_rows:
        item = by_id[row['id']]
        assert row['value'] == item['source']
        family = next(f for prefix, f in families.items() if row['hierarchy'].startswith(prefix + '/'))
        contexts.append(dict(item, originalSourceContext=row,
            effectiveBinding=dict(color=family['color'], activeTitleVariant='Title (2)',
                activeTitleGameObject=family['variants']['Title (2)']['gameObject'],
                activeTitleLayers=family['variants']['Title (2)']['layers'],
                interpretation='Original ancestor flags describe the source before the accepted shared title-flow activation. Reuse exact accepted consumer evidence, not source activation flags as current state.')))
    components = dict(previousClosure=[r['id'] for r in catalog if r['id'] in old_ids],
        completeFourBellFamily=[r['id'] for r in catalog if r['id'] in family_ids],
        currentClosure=[r['id'] for r in catalog if r['id'] in current_ids],
        corrected=[r['id'] for r in catalog if r['id'] in changed],
        addedDependencies=[r['id'] for r in catalog if r['id'] in added], removedDependencies=[],
        exactDelta=[r['id'] for r in catalog if r['id'] in delta])
    policy = dict(selector='Enumerate all four contract family hierarchies and every admitted direct-text descendant; retain earlier mandatory closure, then exact set difference.',
        inputs=[dict(path=str(p.relative_to(ROOT)), sha256=sha(p)) for p in
                [language, old_scope_path, source_path, contract_path, Path(__file__).resolve()]],
        components=components, rationale='The newly explicit Blue family is the positive control for the same shared full-title mechanism. No unchanged prior reviewed ID is promoted or automatically reread.',
        acceptance='Deterministic selection only; fresh independent model judgments still required.')
    (here / 'closure-policy.json').write_text(json.dumps(policy, indent=2) + '\n')
    write_rows(here / 'current-closure-packet.jsonl', packet)
    write_rows(here / 'complete-bell-context.jsonl', contexts)
    write_rows(here / 'authored-review.jsonl', [by_id[r['id']] for r in corrections])
    evidence = dict(path=str((here / 'closure-policy.json').relative_to(ROOT)), sha256=sha(here / 'closure-policy.json'))
    dependencies = [dict(id=r['id'], causedBy=[c['id'] for c in corrections],
        reason='Newly explicit unchanged Blue positive-control surface in the same complete four-color title-flow binding; verify source-faithful Blue wording and preserve it.', evidence=evidence)
        for r in catalog if r['id'] in added]
    write_rows(here / 'new-dependencies.jsonl', dependencies)
    scope = prepare_scope(ROOT, here / 'current-closure-packet.jsonl', here / 'authored-review.jsonl',
                          here / 'independent-scope', dependencies)
    assert set(scope['reviewIds']) == delta
    for name, ids in components.items():
        (here / (name + '-ids.txt')).write_text(''.join(x + '\n' for x in ids))
    print(json.dumps(dict(currentClosure=len(current_ids), corrected=len(changed),
                         addedDependencies=len(added), exactDelta=len(delta), requiredBellContext=len(contexts))))


if __name__ == '__main__':
    main()
