import json,pathlib,sys
PH=pathlib.Path(__file__).parent; B=pathlib.Path('localization/editorial-delivery/pt-BR-single-file-20261101-01/final-v2')
r=[json.loads(x) for x in (B/'independent-scope/review-packet.jsonl').read_text().splitlines()]
a=json.loads(sys.stdin.read());p=PH/'judgments.jsonl';existing=[json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []
for j in a:
 i=j.pop('index'); x=r[i]; assert not any(v['id']==x['id'] for v in existing)
 existing.append({'id':x['id'],'sourceSha256':x['sourceSha256'],'targetSha256':x['targetSha256'],**j})
p.write_text(''.join(json.dumps(x,ensure_ascii=False)+'\n' for x in existing))
print('Explicit model-authored judgments saved:',len(existing))
