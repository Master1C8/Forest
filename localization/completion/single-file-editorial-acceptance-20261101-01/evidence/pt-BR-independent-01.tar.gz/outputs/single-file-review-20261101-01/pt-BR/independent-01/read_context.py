import json,pathlib,sys,collections,hashlib
ROOT=pathlib.Path('/Users/antonkrutov/Desktop/Forest'); PH=ROOT/'outputs/single-file-review-20261101-01/pt-BR/independent-01'; BASE=ROOT/'localization/editorial-delivery/pt-BR-single-file-20261101-01/final-v2'
rows=[json.loads(x) for x in (BASE/'closure-packet.jsonl').read_text().splitlines()]
tree=json.loads((ROOT/'assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json').read_text()); cs={c['id']:c for c in tree['conversations']}; required=set(json.loads((BASE/'independent-scope/scope.json').read_text())['reviewIds'])
def emit(x):print(json.dumps(x,ensure_ascii=False,separators=(',',':')))
start,end=map(int,sys.argv[1:3]); seen=set()
for i,r in enumerate(rows[start:end],start):
 out={'n':i,'id':r['id'],'required':r['id'] in required,'en':r['source'],'pt':r['target']}
 if r['id'].startswith('ds:'):
  _,cid,eid,field=r['id'].split(':',3);c=cs[int(cid)]; e=next(e for e in c['dialogueEntries'] if e['id']==int(eid));
  if c['id'] not in seen: emit({'conversation':c['id'],'fields':[[v['title'],v['value']] for v in c['fields']]});seen.add(c['id'])
  out['fields']=[[v['title'],v['value']] for v in e['fields'] if v['title'] not in ['Dialogue Text','Menu Text'] and v['value'] not in ['', '[]']]
  # Empty values have no additional meaning; all nonempty command/branch and control state retained.
  out['links']=[[v['destinationConversationID'],v['destinationDialogueID'],v['isConnector'],v['priority']] for v in e['outgoingLinks']]
  
  if e['conditionsString']:out['condition']=e['conditionsString']
  if e['userScript']:out['script']=e['userScript']
  default={'isRoot':0,'isGroup':0,'falseConditionAction':'Block','conditionPriority':2}; diff={k:e[k] for k in default if e[k]!=default[k]}
  if diff:out['flags']=diff
 emit(out)
