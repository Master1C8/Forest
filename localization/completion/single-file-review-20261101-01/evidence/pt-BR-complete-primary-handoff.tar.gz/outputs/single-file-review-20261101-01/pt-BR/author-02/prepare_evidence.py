import json,hashlib,sys,collections
from pathlib import Path
sys.path.insert(0,'tools')
from forest_localization import core
R=Path.cwd();O=Path(__file__).parent;B=R/'localization/editorial-delivery/pt-BR-single-file-20261101-01';D=B/'final-v2'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sh(s):return hashlib.sha256(s.encode()).hexdigest()
def rel(p):return str(p.relative_to(R))
def bind(p):return dict(path=rel(p),sha256=sha(p),bytes=p.stat().st_size)
def read(p):return json.loads(p.read_text())
def rows(p):return [json.loads(x) for x in p.read_text().splitlines()]
def write(p,d):p.write_bytes(core.encode(d))
def lines(p,rs):p.write_text(''.join(json.dumps(r,ensure_ascii=True,sort_keys=True)+'\n' for r in rs))
P=rows(D/'complete-packet.jsonl');by={r['id']:r for r in P};changes=rows(D/'new-repairs.jsonl');new={r['id']:r for r in changes};runtime=bind(O/'runtime-verification.json');initial=read(O/'task.json')['job']['initialLanguageSha256'];language=bind(R/'localization/languages/pt-BR.json')
# Check original evidence files once, not once per ID.
oldManifest=read(B/'manifest.json')
for x in oldManifest['files']:assert sha(R/x['path'])==x['sha256'],x['path']
retained=[]
for name in ['primary-judgments.jsonl','gallery-primary-judgments.jsonl']:
 for j in rows(B/name):
  p=by[j['id']];assert all(j[f]==p[f] for f in ['sourceSha256','targetSha256']),j['id']
  retained.append(dict(j,evidence=bind(B/name),applicability='Retained exact source/target; same pinned current glossary and source/context; not independent.'))
assert len(retained)==514 and len({r['id'] for r in retained})==514
missing=set((B/'remaining-primary-linguistic-ids.txt').read_text().splitlines());judged={};batchbind=[]
for f in sorted((O/'judgments').glob('*.json')):
 j=read(f);fbind=bind(f);assert j['readComplete'];b=O/'batches'/(j['batch']+'.txt');assert sha(b)==j['readRepresentationSha256'];batchbind.append(fbind)
 for v in j['versions']:
  ident=v['id'];assert ident in missing and ident not in judged
  orig=nextrow=None
  p=by[ident];assert p['sourceSha256']==v['sourceSha256']
  if ident not in new:assert p['targetSha256']==v['targetSha256']
  else:assert new[ident]['beforeSha256']==v['targetSha256']
  judged[ident]=dict(id=ident,sourceSha256=p['sourceSha256'],targetSha256=p['targetSha256'],reviewType='actual-primary-source-target-proofreading',independent=False,readComplete=True,semanticDecision=dict(path=rel(f),sha256=fbind['sha256'],readRange=j['readRange'],verdict=j['verdict']),rationale=j['rationale'],disposition='reviewed-retained' if ident not in new else 'reviewed-repaired',resolution=bind(D/'finding-adjudications.json') if j['verdict']!='pass' or ident in new else None)
assert set(judged)==missing and len(judged)==12311
protected=read(R/'localization/completion/single-file-parallel-20261101-01/shared/source-preservation.json')['baselinePreserved'];assert len(protected)==1781
pres=[]
for ident,h in protected.items():
 p=by[ident];assert p['sourceSha256']==p['targetSha256']==h
 pres.append(dict(id=ident,sourceSha256=h,targetSha256=h,disposition='exact-source-policy-preserved',linguisticPass=False))
semantic={r['id'] for r in retained}|set(judged);assert len(semantic)==12825;assert not semantic&set(protected);assert semantic|set(protected)==set(by)
lines(D/'primary-ledger.jsonl',retained+[judged[k] for k in sorted(judged)]);lines(D/'source-preservation-proof.jsonl',pres);(D/'remaining-unread-ids.txt').write_text('');(O/'remaining-unread-ids.txt').write_text('')
# Source-aware parser exercises actual control/numeric/service-prefix and exact-preservation guards for every dialogue row.
guard=core.module(R/'localization/ru-assets/inline_guard.py','forest_inline_guard_finalpt');sources={r['id']:r for r in rows(R/'localization/source/dialogue-candidates.jsonl')};dispositions=guard.load_dispositions(R/'localization/ru-assets/source-dispositions.json',R,sources);count=0
for ident,row in sources.items():
 if ident in by:core.validate_dialogue(guard,row,by[ident]['target'],dispositions.get(ident));count+=1
assert count==12246
write(D/'static-preflight.json',dict(language=language,catalogUnits=len(P),readMissingPrimary=len(judged),retainedFreshPrimary=len(retained),linguisticallyReviewed=len(semantic),sourcePolicyPreserved=len(pres),unreadCount=0,unresolvedFindings=[],dialogueControlGuard=dict(count=count,sourceAware=True,sourceDispositionCount=len(dispositions),result='pass'),bindings=[bind(R/x) for x in ['localization/completion/single-file-parallel-20261101-01/shared/source-preservation.json','localization/completion/single-file-parallel-20261101-01/shared/glossary-en.json','localization/completion/single-file-parallel-20261101-01/pt-BR/glossary.json','assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json','localization/framework/forest045-shared-v2/catalog.json']],runtime=runtime,batchEvidence=batchbind,newDeltaSelfReview=bind(D/'new-repairs.jsonl'),independentAcceptance=False,nativeAcceptance=False))
# Reproducible closure: old authored versions + new repairs; preserve old mandatory context.
oldAuthored=rows(B/'authored132.jsonl');authored={r['id'] for r in oldAuthored}|set(new)
assert len(authored)==137
for r in oldAuthored:assert r['source']==by[r['id']]['source'] and r['target']==by[r['id']]['target']
context={r['id'] for r in rows(B/'closure-packet.jsonl')};tree=read(R/'assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json');selectedScenes={120,297,352,527};sceneids=set()
for c in tree['conversations']:
 if c['id'] in selectedScenes:
  for e in c['dialogueEntries']:
   for field in ['Dialogue Text','Menu Text']:
    ident=f"ds:{c['id']}:{e['id']}:{field}"
    if ident in by:sceneids.add(ident)
# Include the elder's other understandable English lines and initial fluff greetings as necessary native context.
elderContext={'ds:505:1131:Dialogue Text','ds:505:1222:Dialogue Text'}|{r['id'] for r in P if any(r['id'].startswith(f'ds:{n}:') for n in range(497,505))}
closure=context|sceneids|elderContext|authored
lines(D/'authored137.jsonl',[{k:r[k] for k in ['id','source','target','sourceSha256','targetSha256']} for r in P if r['id'] in authored]);lines(D/'closure-packet.jsonl',[r for r in P if r['id'] in closure]);(D/'changed-ids.txt').write_text(''.join(k+'\n' for k in sorted(new)))
policy=dict(selectorVersion=1,recipe='Union the old exact closure IDs, current authored132 IDs and new repairs; include all catalog Dialogue/Menu Text in source conversations120,297,352,527, elder505:1131/1222 and greeting conversations497–504. Only the actual partner misunderstanding/clarification rows are invalidated target dependencies.',originalClosure=bind(B/'closure-packet.jsonl'),oldAuthored=bind(B/'authored132.jsonl'),newRepairs=bind(D/'new-repairs.jsonl'),sourceTree=bind(R/'assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json'),mandatoryRegressions=read(B/'closure-components.json')['mandatory-regressions'],sceneIds=sorted(selectedScenes),unchangedContextIds=sorted(closure-authored),authoredIds=sorted(authored),invalidatedIds=['ds:297:137:Dialogue Text','ds:297:138:Dialogue Text','ds:297:139:Dialogue Text'])
write(D/'closure-policy.json',policy)
deps=[dict(id=f'ds:297:{n}:Dialogue Text',causedBy=['ds:297:134:Dialogue Text','ds:297:136:Dialogue Text'],reason=reason,evidence=bind(D/'closure-policy.json')) for n,reason in [(137,'Business-partner punchline must follow the restored ambiguous parceiro noun.'),(138,'Seven-percent business continuation must retain the business interpretation now restored by the preceding changed noun.'),(139,'Relationship-partner clarification must close the restored same-noun misunderstanding.')]]
lines(D/'invalidated-dependencies.jsonl',deps)
write(O/'checkpoint.json',dict(status='primary-complete-build-in-progress',language=language,primaryRead=12311,retainedPrimary=514,sourcePreserved=1781,unreadCount=0,newRepairs=5,independentAcceptance=False,next='Finish static build/check and freeze final-v2 handoff.'))
print(json.dumps(dict(semantic=len(semantic),protected=len(protected),unread=0,authored=len(authored),closure=len(closure),dependencies=len(deps),controls=count)))
