import json,hashlib,sys
from pathlib import Path
sys.path.insert(0,'tools')
from forest_localization.core import encode
R=Path.cwd();O=Path(__file__).parent;old=R/'localization/editorial-delivery/pt-BR-single-file-20261101-01';D=old/'final-v2';I=R/'localization/language-imports/pt-BR-20261101/final-v2'
D.mkdir(exist_ok=False);I.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def sh(s):return hashlib.sha256(s.encode()).hexdigest()
def write(p,d):p.write_bytes(encode(d))
def rows(p):return [json.loads(x) for x in p.read_text().splitlines()]
def lines(p,rs):p.write_bytes(b''.join(encode(r).rstrip().replace(b'\n',b'')+b'\n' for r in [])) if False else p.write_text(''.join(json.dumps(r,ensure_ascii=True,sort_keys=True)+'\n' for r in rs))
L=R/'localization/languages/pt-BR.json';task=json.loads((O/'task.json').read_text());assert sha(L)==task['job']['initialLanguageSha256'];lang=json.loads(L.read_text());t=lang['translations'];packet=rows(old/'complete-packet.jsonl');by={r['id']:r for r in packet}
for p,h in task['job']['immutablePins'].items():assert sha(R/p)==h,p
repairs={
'bgdb:resources.assets:320/sheet/9yCd%2Fl1J50q4ulgVkTG%2BqQ/row/eqvoNX7toEiuxwVzJcQ5fg/field/9bk2imQPcUGONvg3gpNiWw':('Diga oi à coelha.','Exact Act1_TutorialQuest_0 objective names Scarlett by species; tutorial scene and actor2 bind a female bunny, requiring coelha.'),
'ds:297:134:Dialogue Text':('Você tem um parceiro?','Restore the ambiguous partner noun required by the business-partner misunderstanding and subsequent relationship clarification.'),
'ds:297:136:Dialogue Text':('[pic=3]Um parceiro? Não, este negócio aqui é bem individual.','Repeat parceiro so the business interpretation follows the same ambiguous noun; retain speaker, business and individual venture.'),
'ds:352:55:Dialogue Text':('[pic=1]Travesso! Mais uma vez, parabéns pelo trabalho na ponte! A gente agradece a ajuda!','Again repeats praise for the one completed bridge, rather than asserting a second bridge-building event.'),
'ds:527:759:Dialogue Text':('[pic=1]Grata! Grata ao peludão!','This understandable English elder line is outside the 1781 protected source-policy IDs. Translate simple gratitude in the female elder voice; preserve hesitant/simple register and pic command.')}
changes=[]
for k,(target,reason) in repairs.items():
 r=by[k];assert t[k]=={'source':r['source'],'target':r['target']};assert target!=r['target']
 changes.append(dict(id=k,source=r['source'],sourceSha256=r['sourceSha256'],before=r['target'],beforeSha256=r['targetSha256'],target=target,targetSha256=sh(target),rationale=reason,reviewType='consolidated-authored-repair-and-exact-delta-self-review',independent=False,verdict='pass'))
 t[k]['target']=target
# Every hold was adjudicated by actual source/context reading; retain dismissals, not just edits.
resolutions=[
 dict(family='Dustin Training',ids=['bgdb:resources.assets:320/sheet/l7q0WkqA70qZcKsOchc8NQ/row/ybzdUtAhlEuUzxB5SUo0cg/field/QtfPU7c06U6IYvVCzuqTMg'],decision='retain',rationale='Exact dependency binding points to conversation133 entry496 BIO(squirrel,kink_training), immediately before entry292 explicitly distinguishes anal from athletic stretching. Complete scene133 was read. Treino anal is supported context, not an invented qualifier.'),
 dict(family='Bucky anal conversation',ids=['ds:176:154:Dialogue Text'],decision='retain',rationale='Source expressly says going down on me. The next deep-partner line does not justify replacing its literal oral meaning. Preserve source inconsistency/euphemism rather than inventing anal penetration in this exact line.'),
 dict(family='TALK/GOSSIP help names',ids=[r['id'] for r in packet if r['source'].startswith(('The Critters of the forest love to talk!','GOSSIP will reveal a lot','The TALK button is for quests'))],decision='retain',rationale='Candidate assumed registered target buttons FALAR/CONVERSA, but no such text targets exist in this compiler catalog. Source texture inventory instead contains InteractButton_Talk and InteractButton_Gossip and shadow variants. English here explicitly names controls; Conversa remains the glossary mechanic. No verified target-label mismatch warrants replacing those names. Exact rendered artwork correspondence remains a native gate, not a semantic default pass.'),
 dict(family='haiku display/evaluation and poem quotations',ids=[r['id'] for r in packet if r['id'].startswith('managed:') and r['source'] in ['We shape the earth','Over raging waters','To unite friends']],decision='retain',rationale='All nine authored managed choices were read, then complete conversation303 including choice, branch, poem and critique context (122 units), and complete302 quoted poem context. Corresponding display wording is equal, bridge/bug/falcon groups remain coupled; natural elisions allow 5-7-5. No alphabet-specific acceptance guard was used. See batch004980-005160 and original haiku-context-read evidence.')
]
# Existing and new values match except for the five deliberate repairs; no controls or source edits.
assert len(t)==len(packet)==14606
assert {k for k,v in t.items() if v['target']!=by[k]['target']}==set(repairs)
assert all(v['source']==by[k]['source'] for k,v in t.items())
L.write_bytes(encode(lang));(D/'language-reviewed.json').write_bytes(L.read_bytes());(I/'language-reviewed.json').write_bytes(L.read_bytes())
lines(D/'new-repairs.jsonl',changes);write(D/'finding-adjudications.json',dict(repairs=changes,retained=resolutions,unresolved=[]))
final=[]
for r in packet:final.append(dict(r,target=t[r['id']]['target'],targetSha256=sh(t[r['id']]['target'])))
lines(D/'complete-packet.jsonl',final)
write(I/'provenance.json',dict(source='exact canonical pt-BR JSON after complete missing primary audit',languageSha256=sha(L),initialLanguageSha256=task['job']['initialLanguageSha256'],newRepairs=dict(path=str((D/'new-repairs.jsonl').relative_to(R)),sha256=sha(D/'new-repairs.jsonl')),independentAcceptance=False))
print(json.dumps(dict(languageSha256=sha(L),repairs=len(changes),retainedFindings=len(resolutions),helpCopies=len(resolutions[2]['ids']))))
