import json,sys,hashlib
from pathlib import Path
O=Path(__file__).parent
name=sys.argv[1]; data=json.loads((O/'batches'/(name+'.json')).read_text());decision=json.load(sys.stdin)
assert decision.get('readComplete') is True and decision.get('rationale') and isinstance(decision.get('findings'),list)
f=O/'judgments';f.mkdir(exist_ok=True)
result={'batch':name,'reviewType':'actual-primary-source-target-proofreading','independent':False,'runtimeVerificationSha256':hashlib.sha256((O/'runtime-verification.json').read_bytes()).hexdigest(),'readRepresentationSha256':data['readRepresentationSha256'],'readRange':[data['start'],data['end']],**decision,'versions':[{'id':r['id'],'sourceSha256':r['sourceSha256'],'targetSha256':r['targetSha256']} for r in data['rows']]}
with (f/(name+'.json')).open('x') as w:json.dump(result,w,ensure_ascii=True,sort_keys=True,indent=2);w.write('\n')
print('Recorded',len(result['versions']),'actual judgments;',len(decision['findings']),'findings')
