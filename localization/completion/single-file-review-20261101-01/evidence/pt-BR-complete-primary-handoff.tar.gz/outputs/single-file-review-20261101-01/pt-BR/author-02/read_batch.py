import json,sys,hashlib
from pathlib import Path
ROOT=Path('/Users/antonkrutov/Desktop/Forest'); B=ROOT/'localization/editorial-delivery/pt-BR-single-file-20261101-01'; O=Path(__file__).parent
rows=[json.loads(s) for s in (B/'complete-packet.jsonl').read_text().splitlines()]; by={r['id']:r for r in rows};remaining=set((B/'remaining-primary-linguistic-ids.txt').read_text().splitlines()); tree=json.loads((ROOT/'assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json').read_text()); actors=json.loads((ROOT/'localization/completion/single-file-parallel-20261101-01/shared/actor-roster.json').read_text())
ordered=[]; contexts={}
for r in rows:
 if not r['id'].startswith('ds:') and r['id'] in remaining:ordered.append(r)
for c in tree['conversations']:
 cf={f['title']:f['value'] for f in c['fields']}
 for e in c['dialogueEntries']:
  f={f['title']:f['value'] for f in e['fields']}; ident=f"ds:{c['id']}:{e['id']}:Dialogue Text"
  contexts[ident]={'scene':cf.get('Title'),'speaker':actors.get(f.get('Actor'),{}).get('Name',f.get('Actor')),'to':actors.get(f.get('Conversant'),{}).get('Name',f.get('Conversant')),'condition':e.get('conditionsString'),'next':[[z['destinationConversationID'],z['destinationDialogueID']] for z in e['outgoingLinks']]}
  if ident in remaining:ordered.append(by[ident])
present={r['id'] for r in ordered}
missing=remaining-present
print('Ordering reconciliation',len(ordered),len(remaining),len(missing),list(missing)[:8],file=sys.stderr)
ordered.extend(r for r in rows if r['id'] in missing)
assert len(ordered)==len(remaining)==12311
start,end=map(int,sys.argv[1:3]); batch=ordered[start:end]; out=[]; prev=None
for n,r in enumerate(batch,start):
 c=contexts.get(r['id']);
 if c and c['scene']!=prev:out.append('\nSCENE '+str(c['scene']));prev=c['scene'] if c else None
 out.append(f"{n} {r['id']}"+(f" {c['speaker']}->{c['to']}"+(f" if={c['condition']}" if c['condition'] else '')+(f" branches={c['next']}" if len(c['next'])>1 else '') if c else ''))
 out.append('EN '+json.dumps(r['source'],ensure_ascii=False));out.append('PT '+json.dumps(r['target'],ensure_ascii=False))
if len(sys.argv)>3 and sys.argv[3]=='intern':
 groups={}
 for n,r in enumerate(batch,start):
  assert not r['id'].startswith('ds:')
  key=(r['source'],r['target']);groups.setdefault(key,[]).append((n,r['id']))
 out=[]
 for (source,target),members in groups.items():
  out.append('MEMBERS '+json.dumps(members,ensure_ascii=False,separators=(',',':')))
  out.append('EN '+json.dumps(source,ensure_ascii=False));out.append('PT '+json.dumps(target,ensure_ascii=False))
content='\n'.join(out)+'\n';print(content)
p=O/'batches';p.mkdir(exist_ok=True);name=f'{start:05}-{end:05}';(p/(name+'.txt')).write_text(content);(p/(name+'.json')).write_text(json.dumps({'start':start,'end':end,'rows':batch,'contexts':{r['id']:contexts[r['id']] for r in batch if r['id'] in contexts},'readRepresentationSha256':hashlib.sha256(content.encode()).hexdigest()},ensure_ascii=False)+'\n')
