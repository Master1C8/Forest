"""Task-local deterministic application of model-authored Portuguese wording."""
import json,sys,hashlib
from pathlib import Path
sys.path.insert(0,'tools')
from forest_localization import core
B=Path('localization/language-imports/pt-BR-20261101')
d=json.load(open(B/'recovered.json'));cat=json.load(open('localization/framework/forest045-shared-v2/catalog.json'))
# Explicit phrases authored/read by this execution; no generated translation.
wording={
 'Play':'Jogar','Start New Game':'Novo jogo','Report a Bug':'Relatar um bug','Options\n':'Opções\n','Gallery':'Galeria',
 'If you are a kid, <color=#EE1005><u>GET OUTA HERE!</u></color>\nIf not, please enjoy!':'Se você é criança, <color=#EE1005><u>CAI FORA DAQUI!</u></color>\nSe não é, aproveite!',
 'This is an <color=#EE1005><u>ADULT GAME</u></color> featuring a ton\nof <color=#EE1005><u>EXPLICIT CONTENT.</u></color>':'Este é um <color=#EE1005><u>JOGO ADULTO</u></color> com muito\n<color=#EE1005><u>CONTEÚDO EXPLÍCITO.</u></color>',
 'Hey Rascal!':'Oi, Travesso!','Hits: ':'Golpes: ','Completed':'Concluídas','Active':'Ativas',
 '<size=22></size>HE <size=22>P</size>URPLE <size=22>B</size>ELL':'<size=22>O</size> <size=22>S</size>INO <size=22>R</size>OXO',
 '<size=22></size>HE <size=22>B</size>LUE <size=22>B</size>ELL':'<size=22>O</size> <size=22>S</size>INO <size=22>A</size>ZUL',
 '<size=22></size>HE <size=22>R</size>ED <size=22>B</size>ELL':'<size=22>O</size> <size=22>S</size>INO <size=22>V</size>ERMELHO',
 '<size=22></size>HE <size=22>G</size>REEN <size=22>B</size>ELL':'<size=22>O</size> <size=22>S</size>INO <size=22>V</size>ERDE',
}
changes=[]
for k,v in d['translations'].items():
 if v['target'] is None and v['source'] in wording:
  changes.append(dict(id=k,source=v['source'],before=None,after=wording[v['source']],reason='Complete explicit Portuguese UI/adapter wording; preserve source markup roles, joins and exact source identity.'));v['target']=wording[v['source']]
# Accepted shared selector roles establish the four cloned bell consumers.
bell_roles={
 'purple':[14014,14971,16394,16446,17205,17809],
 'blue':[14016,14973,16396,16448,17207,17811],
 'red':[14017,14974,16397,16449,17208,17812],
 'green':[14020,14977,16400,16452,17211,17815],
}
bell_targets={'purple':'<size=22>O</size> <size=22>S</size>INO <size=22>R</size>OXO','blue':'<size=22>O</size> <size=22>S</size>INO <size=22>A</size>ZUL','red':'<size=22>O</size> <size=22>S</size>INO <size=22>V</size>ERMELHO','green':'<size=22>O</size> <size=22>S</size>INO <size=22>V</size>ERDE'}
for role,ids in bell_roles.items():
 for pid in ids:
  k=f'sharedassets2.assets:{pid}/m_text';v=d['translations'][k];assert v['source']=='<size=22>T</size>HE <size=22>B</size>LUE <size=22>B</size>ELL'
  if v['target']!=bell_targets[role]:changes.append(dict(id=k,source=v['source'],before=v['target'],after=bell_targets[role],reason='Copied BLUE source uses the exact '+role+' bell consumer in the accepted shared baseline.'));v['target']=bell_targets[role]
# Service-looking prefixes remain exact; only the visible question is localized.
for k,before,after in [
 ('ds:227:180:Dialogue Text','CONSELHO Quem manda aqui?','ADVICE Quem manda aqui?'),
 ('ds:228:161:Dialogue Text','CONSELHO Sabe de alguma fofoca quente?','ADVICE Sabe de alguma fofoca quente?'),
]:
 v=d['translations'][k];assert v['target']==before
 changes.append(dict(id=k,source=v['source'],before=before,after=after,reason='Restore exact ADVICE service prefix under source-bound disposition; preserve Portuguese question.'));v['target']=after
# Apply explicit current-glossary sexual-role revisions by exact reviewed record.
candidates=json.load(open(B/'role-term-candidates.json'))
terms=json.load(open(B/'role-terminology-authored.json'))
for index,after in terms.items():
 r=candidates[int(index)];k=r['id'];v=d['translations'][k]
 assert v['source']==r['source'] and v['target']==r['target']
 changes.append(dict(id=k,source=v['source'],before=v['target'],after=after,reason='Current approved pt-BR glossary tfol-147/148/149; sexual position is distinct from dominance, activity and physical above/below.'));v['target']=after
assert not [k for k,v in d['translations'].items() if v['target'] is None]
B.joinpath('author-changes.json').write_bytes(core.encode(changes))
Path('localization/languages/pt-BR.json').write_bytes(core.encode(d))
print(json.dumps(dict(units=len(d['translations']),changes=len(changes),languageSha256=core.digest(core.encode(d)))))
