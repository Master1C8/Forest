"""Deterministic evidence/closure preparation; never creates semantic verdicts."""
import json,hashlib,sys,re,collections
from pathlib import Path
sys.path.insert(0,'tools')
from forest_localization import core
ROOT=Path.cwd();B=Path('localization/language-imports/pt-BR-20261101');P=Path('localization/editorial-delivery/pt-BR-single-file-20261101-01');R=Path('outputs/single-file-parallel-20261101-01/pt-BR/author-01')
read=lambda p:json.loads(Path(p).read_text())
sha=lambda x:hashlib.sha256(x.encode()).hexdigest()
def rows_write(path,rows):
 with Path(path).open('x') as f:
  for r in rows:f.write(json.dumps(r,ensure_ascii=True,sort_keys=True)+'\n')
L=Path('localization/languages/pt-BR.json');doc=read(L);D=doc['translations'];C=read('localization/framework/forest045-shared-v2/catalog.json');CM={r['id']:r for r in C};changes=read(B/'author-changes.json');CH={r['id']:r for r in changes};assert len(CH)==len(changes)
# Preserve the exact file used by this review cycle.
(P/'language-reviewed.json').write_bytes(L.read_bytes())
groups=read(P/'primary-groups.json');rat=read(P/'primary-rationales.json');assert set(rat)=={str(i) for i in range(82)}
primary=[]
for g in groups:
 assert len(g['ids'])==len(set(g['ids']))
 for k in g['ids']:
  v=D[k];assert v['source']==g['source'] and v['target']==g['target']
  primary.append(dict(id=k,sourceSha256=sha(v['source']),targetSha256=sha(v['target']),verdict='pass',independent=False,reviewType='actual-primary-source-target-proofreading',groupIndex=g['groupIndex'],rationale=rat[str(g['groupIndex'])]))
roles=read(B/'role-term-candidates.json');terms=read(B/'role-terminology-authored.json')
for i,after in terms.items():
 r=roles[int(i)];k=r['id'];assert D[k]['target']==after
 reason='The reviewed complete exchange distinguishes sexual position from dominance/submission and from ordinary activity. The explicit replacement preserves the utterance and approved top/bottom terminology.'
 if i=='2':reason='Bottom is the approved sexual-role caption; source capitalization is retained and the stored role identity is untouched.'
 elif i=='38':reason='recebendo preserves the source receiving-end question in Penny/Mabel/Travesso context without converting a situational preference into an added fixed personality label.'
 elif i in ['62','64']:reason='bottom remains the approved role; poderoso/poderosa preserves the source power-bottom wordplay and its power-generation callback. Source LF and known speaker agreement are retained.'
 primary.append(dict(id=k,sourceSha256=sha(r['source']),targetSha256=sha(after),verdict='pass',independent=False,reviewType='actual-primary-source-target-proofreading',rationale=reason))
assert len(primary)==len({r['id'] for r in primary})==401
rows_write(P/'primary-judgments.jsonl',primary)
# Exact gallery context join; all 113 registered rows were actually read in the compact view.
gallery=[json.loads(l) for l in open('localization/source/gallery-chapter-display-20261028/admission-v1/consumer-context.jsonl')]
G=[]
for r in gallery:
 if r['id'] not in D:continue
 k=r['id'];v=D[k];assert v['source']==r['source'] and sha(v['source'])==r['sourceUtf8Sha256']
 G.append(dict(id=k,sourceSha256=sha(v['source']),targetSha256=sha(v['target']),verdict='pass',independent=False,reviewType='actual-primary-gallery-regression',rationale='Compared complete source/target with the exact registered consumer decision: '+r['sourceDecision']))
assert len(G)==113
rows_write(P/'gallery-primary-judgments.jsonl',G)
# All conversation303 source/target units were actually read; technical source annotations remain disposition context.
source_rows=[json.loads(l) for l in open('localization/pt-BR-assets/dialogue.pt-BR.jsonl')];H=[]
for r in source_rows:
 if r['conversationId']!=303:continue
 v=D[r['id']]
 H.append(dict(id=r['id'],sourceSha256=sha(v['source']),targetSha256=sha(v['target']),independent=False,reviewType='actual-source-target-haiku-context-read',rationale='Read in full with the nine choice lines, both named bridge/bug/falcon callback paths, mixed response, shared close and Oliver/Violet correction exchange; annotations/name markers remain disposition context.'))
rows_write(P/'haiku-context-read.jsonl',H)
# Immutable whole document packet; selectors never provide alternative wording.
packet=[dict(id=k,source=v['source'],target=v['target'],sourceSha256=sha(v['source']),targetSha256=sha(v['target']),selectors=CM[k]['selectors']) for k,v in D.items()]
rows_write(P/'complete-packet.jsonl',packet)
rows_write(P/'authored132.jsonl',[dict(id=k,source=D[k]['source'],target=D[k]['target'],sourceSha256=sha(D[k]['source']),targetSha256=sha(D[k]['target'])) for k in D if k in CH])
# Reproducible bounded closure. Complete changed dialogue conversations are context;
# other groups retain exact source/target repetitions, native normalized layers, gallery and haiku regressions.
changed_sources={r['source'] for r in changes};changed_values={r[f] for r in changes for f in ['before','after'] if isinstance(r[f],str)}
changed_conversations={int(k.split(':')[1]) for k in CH if k.startswith('ds:')}
strip=lambda s:re.sub('<[^>]*>','',s)
changed_native={strip(r['source']) for r in changes if r['id'].startswith(('level','sharedassets'))}
components=collections.defaultdict(list)
for k,v in D.items():
 if k in CH:components['changed'].append(k)
 elif v['source'] in changed_sources or v['target'] in changed_values:components['exact-repetitions'].append(k)
 if k.startswith('ds:') and int(k.split(':')[1]) in changed_conversations:components['containing-exchanges'].append(k)
 if k.startswith(('level','sharedassets')) and strip(v['source']) in changed_native:components['native-visible-layer-family'].append(k)
for k in {r['id'] for r in G+H+primary}:components['mandatory-regressions'].append(k)
selected=set(k for rows in components.values() for k in rows);deps=[]
(P/'closure-components.json').write_bytes(core.encode(dict(components)))
closure_evidence=dict(path=str(P/'closure-components.json'),**core.binding(P/'closure-components.json'))
# Surrounding membership is required context, not automatic evidence invalidation.
# A future genuine invalidation must supply a specific cause and evidence.
for k in D:
 if k in selected and k not in CH:
  deps.append(dict(id=k,components=[n for n,ids in components.items() if k in ids],coverage='required-source-context; no new primary verdict or automatic invalidation',evidence=closure_evidence))
rows_write(P/'source-context-components.jsonl',deps)
for name,ids in [('changed-ids',set(CH)),('closure-ids',selected),('fresh-primary-ids',{r['id'] for r in primary+G}),('not-fresh-primary-ids',set(D)-{r['id'] for r in primary+G})]:
 (P/(name+'.txt')).write_text(''.join(k+'\n' for k in D if k in ids))
# No fresh verdict is inferred for other translated/retained units.
summary=dict(language=dict(path=str(L),**core.binding(L)),units=len(D),newAuthoredIds=len(CH),freshPrimaryProofreading=len(primary),freshGalleryProofreading=len(G),haikuContextRead=len(H),notFreshPrimary=len(set(D)-{r['id'] for r in primary+G}),wholeCorpusSemanticAudit='not-complete; preserved original draft and prior scoped evidence are not promoted to a new complete audit',independentAcceptance='pending; no model or reviewer launched',closureUnits=len(selected))
(P/'coverage.json').write_bytes(core.encode(summary));print(json.dumps(summary))
