# Portuguese (Brazil) single-file migration

The authoritative language file is `localization/languages/pt-BR.json`, culture
`pt-BR`, shared framework `forest045-shared-v2`, Forest 0.45 English source.
It contains all 14,606 exact catalog IDs and no null targets. JSON uses the
shared compiler's `core.encode` representation.

The initial three pinned imports filled 13,634 entries. The 1,781-entry shared
source-preservation manifest restored 612 differing or null values. Exact
hash-verified Portuguese owning records then supplied 287 of the remaining
360 gaps. Explicit authoring supplied the remaining 73. The final author
change ledger has 132 entries: 73 completions, 18 corrected cloned bell
consumers, two restored service prefixes, and 39 current-glossary role revisions.
The colored warning was aligned with its plain glow layers before final delivery.

The original dialogue overlay, batches, composition plan, old jobs and interrupted
drafts are unchanged. `preservation-changes.json` retains exact before/after
values. `recovery-pins.json` identifies the old owning inputs, checked against
their saved result receipts. `author-changes.json` records complete replacements,
including expected old values. `complete_language.py` in the phase output
applies these explicit author decisions; scripts do not generate translations.

All 12,246 dialogue control checks pass. All 1,781 preserved values are exact.
All twelve inventory heading layers are localized. Styled initials are nonempty;
warning foreground/glow wording agrees. Nine haiku display/evaluation pairs use
the Portuguese choices through the shared adapter. The compiler checks actual
saved resources; it does not establish native callbacks, font coverage or layout.

The final static artifact is `dist/Forest-pt-BR-1c8f8a5075fb/`. Earlier
hash-addressed attempts are retained as build history: the first was rejected
at the protected ADVICE prefix, and later successful intermediate artifacts
precede the warning and terminology corrections. Only the final exact language
hash and final compiler check are delivery evidence.

Fresh primary proofreading covers 401 completed/repaired units and 113 gallery
regressions. Conversation 303's 122 units were read as separate source/target
haiku context. This phase does **not** establish a complete fresh semantic audit
of all legacy wording. The original overlay itself calls that wider audit pending.
12,311 non-preserved units remain outside this phase's fresh primary coverage;
the exact list and the 2,067 exact-version historical independent-receipt
candidates are in the editorial handoff. Candidate hash matches are not automatic
current glossary or independent acceptance. The current glossary changes Finley's
biography and top/bottom terminology; actual source roommate references remain.
Human NSFW glossary review stays owner-deferred.

The immutable review handoff is
`localization/editorial-delivery/pt-BR-single-file-20261101-01/`.
It has 132 new authored primary versions and a 1,040-unit closure, with 908 units
kept as required context rather than fabricated new primary passes. No independent
reviewer was launched. Full semantic, independent, target font/layout, native,
runtime, installer and release acceptance remain separate outstanding predicates.
No Git, game, GUI, screenshot, installer, site publication, deployment or server
operation was performed.
