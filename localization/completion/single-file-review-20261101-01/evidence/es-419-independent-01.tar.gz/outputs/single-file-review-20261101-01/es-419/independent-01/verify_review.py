import json,hashlib,collections,datetime
from pathlib import Path
ROOT=Path('/Users/antonkrutov/Desktop/Forest'); P=Path(__file__).resolve().parent; D=ROOT/'localization/editorial-delivery/es-419-single-file-20261101-01/final-v2'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def rows(p):return [json.loads(l) for l in p.read_text().splitlines()]
def binding(p):return {'path':str(p.relative_to(ROOT)),'sha256':sha(p),'bytes':p.stat().st_size}
config=read(P/'task.json');bad=[s for s,h in config['job']['immutablePins'].items() if not (ROOT/s).is_file() or sha(ROOT/s)!=h];assert not bad,bad
runtime=read(P/'runtime-verification.json');meta=[];turns=[]
with Path(runtime['sessionMetadataPath']).open() as f:
 for l in f:
  x=json.loads(l)
  if x.get('type')=='session_meta':meta.append(x['payload'])
  elif x.get('type')=='turn_context':turns.append(x['payload'])
assert len(meta)==1 and meta[0]['id']==runtime['threadId'] and meta[0].get('parent_thread_id') is None and meta[0].get('forked_from_id') is None and meta[0]['model_provider']=='openai'
assert all(x['model']=='gpt-6.1-sol' and x['effort']=='high' for x in turns)
assert read(D/'primary-notes.json')['authorThread']!=runtime['threadId']
packet=rows(D/'independent-scope/review-packet.jsonl');judgments=rows(P/'judgments.jsonl');scope=read(D/'independent-scope/scope.json');by={x['id']:x for x in packet};assert len(by)==len(packet)==1247
assert len(judgments)==len({x['id'] for x in judgments})==1247 and set(by)=={x['id'] for x in judgments}==set(scope['reviewIds'])
lang=read(ROOT/'localization/languages/es-419.json');lt=lang['translations'];assert isinstance(lt,dict)
for x in packet:
 for k in ['source','target']:assert hashlib.sha256(x[k].encode()).hexdigest()==x[k+'Sha256']
 assert lt[x['id']]['source']==x['source'] and lt[x['id']]['target']==x['target']
for j in judgments:
 x=by[j['id']];assert all(j[k]==x[k] for k in ['sourceSha256','targetSha256']) and j['rationale']
 if j['verdict']=='technical-preservation':assert x['source']==x['target'] and x['originalPreserved']
ct=rows(D/'dialogue-context.jsonl');cb={x['id']:x for x in ct};treepath=ROOT/ct[0]['sourceTree']['path'];assert sha(treepath)==ct[0]['sourceTree']['sha256'];tree=read(treepath);cs={c['id']:c for c in tree['conversations']};dialogue=0
for x in packet:
 if not x['id'].startswith('ds:'):continue
 _,c,e,f=x['id'].split(':',3);conv=cs[int(c)];entry=next(v for v in conv['dialogueEntries'] if v['id']==int(e));fields={v['title']:v['value'] for v in entry['fields']};cont=cb[x['id']]
 assert fields[f]==x['source'] and cont['actorId']==fields['Actor'] and cont['conversantId']==fields['Conversant']
 assert cont['links']==entry['outgoingLinks'] and cont['script']==entry['userScript'] and cont['conditions']==entry['conditionsString'];dialogue+=1
gallery=rows(D/'gallery-context-joined.jsonl');assert len(gallery)==113
for x in gallery:assert x['id'] in by and all(x[k]==by[x['id']][k] for k in ['source','target','sourceSha256','targetSha256'])
allr={x['id']:x for x in rows(D/'complete-final-packet.jsonl')};pairs=[]
for n in [325,326,327,406,407,408,410,411,412]:
 x=allr[f'ds:303:{n}:Dialogue Text']; ys=[v for v in allr.values() if v['id'].startswith('managed:') and 'Haiku_Resolve' in v['id'] and v['source']==x['source']];assert len(ys)==1 and ys[0]['target']==x['target'];pairs.append([x['id'],ys[0]['id']])
static=read(ROOT/'outputs/single-file-parallel-20261101-01/es-419/author-01/static-verification-final-v2.json')
for r in static['resources']:assert sha(ROOT/r['path'])==r['sha256']
report={'checkedAtUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':True,'runtime':runtime['actualRuntime'],'threadId':runtime['threadId'],'authorIndependent':True,'immutablePins':len(config['job']['immutablePins']),'pinDrift':bad,'assigned':len(packet),'judged':len(judgments),'missing':0,'verdictCounts':dict(collections.Counter(x['verdict'] for x in judgments)),'primary':len(scope['primaryIds']),'invalidatedDependencies':len(scope['invalidatedDependencies']),'originalDialogueContextMatches':dialogue,'galleryContextExactMatches':len(gallery),'haikuExactDisplayEvaluationPairs':pairs,'savedResourceHashesVerified':len(static['resources']),'bindings':[binding(p) for p in [P/'task.json',P/'runtime-verification.json',D/'manifest.json',D/'independent-scope/scope.json',D/'independent-scope/review-packet.jsonl',D/'dialogue-context.jsonl',D/'gallery-context-joined.jsonl',treepath,ROOT/'localization/languages/es-419.json',ROOT/'localization/completion/single-file-parallel-20261101-01/shared/glossary-en.json',ROOT/'localization/completion/single-file-parallel-20261101-01/es-419/glossary.json',P/'judgments.jsonl']],'boundary':'Deterministic identity, coverage, context and saved-byte checks only. Semantic judgments were model-authored after reading. No native execution or release acceptance.'}
with (P/'input-version-context-verification.json').open('x') as f:json.dump(report,f,ensure_ascii=False,indent=2);f.write('\n')
print(json.dumps({k:report[k] for k in ['passed','immutablePins','assigned','judged','missing','verdictCounts','originalDialogueContextMatches','galleryContextExactMatches','savedResourceHashesVerified']}))
