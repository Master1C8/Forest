import json,sys,hashlib
from pathlib import Path
BASE=Path('/Users/antonkrutov/Desktop/Forest');PHASE=BASE/'outputs/single-file-review-20261101-01/es-419/independent-01';D=BASE/'localization/editorial-delivery/es-419-single-file-20261101-01/final-v2'
def read(n):return [json.loads(l) for l in (D/n).read_text().splitlines()]
rows=read('independent-scope/review-packet.jsonl'); contexts={r['id']:r for r in read('dialogue-context.jsonl')}
allrows={r['id']:r for r in read('complete-final-packet.jsonl')}
start,end=map(int,sys.argv[1:3]);tree=json.loads((BASE/'assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json').read_text());convs={c['id']:c for c in tree['conversations']}
seen_convs=set()
for i in range(start,end):
 r=rows[i]; o={'n':i,'id':r['id'],'s':r['source'],'t':r['target'],'preserve':r['originalPreserved']}
 if r['id'].startswith('ds:'):
  _,c,e,f=r['id'].split(':',3);c=int(c);e=int(e);conv=convs[c];entry=next(x for x in conv['dialogueEntries'] if x['id']==e)
  fields={x['title']:x['value'] for x in entry['fields']}
  if c not in seen_convs: print('CONVERSATION',c,json.dumps({x['title']:x['value'] for x in conv['fields'] if x['value'] not in ('','[]')},ensure_ascii=False));seen_convs.add(c)
  o['context']={'fields':{k:v for k,v in fields.items() if k!='Dialogue Text' and v not in ('','[]')},'conditions':entry['conditionsString'],'script':entry['userScript'],'links':[[l['destinationConversationID'],l['destinationDialogueID'],l['isConnector'],l['priority']] for l in entry['outgoingLinks']]}
 else:o['context']=r['contextRefs'];o['selectors']=r['selectors']
 print(json.dumps(o,ensure_ascii=False,separators=(',',':')))
with (PHASE/'reading-log.jsonl').open('a') as f:f.write(json.dumps({'range':[start,end],'packetSha256':hashlib.sha256((D/'independent-scope/review-packet.jsonl').read_bytes()).hexdigest(),'mode':'full wording, original dialogue fields/conditions/scripts/links or resource refs/selectors'})+'\n')
