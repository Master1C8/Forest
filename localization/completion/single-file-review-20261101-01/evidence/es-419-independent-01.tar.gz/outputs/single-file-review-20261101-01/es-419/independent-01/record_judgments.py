import json,sys
from pathlib import Path
p=Path(__file__).resolve().parent
r=[json.loads(l) for l in (p.parents[3]/'localization/editorial-delivery/es-419-single-file-20261101-01/final-v2/independent-scope/review-packet.jsonl').read_text().splitlines()]
existing={json.loads(l)['id'] for l in (p/'judgments.jsonl').read_text().splitlines()} if (p/'judgments.jsonl').exists() else set()
with (p/'judgments.jsonl').open('a') as f:
 for line in sys.stdin:
  if not line.strip():continue
  parts=line.rstrip('\n').split('\t'); nums,verdict,reason=parts[:3]
  for n in map(int,nums.split(',')):
   x=r[n];assert x['id'] not in existing,x['id'];existing.add(x['id'])
   d={k:x[k] for k in ['id','sourceSha256','targetSha256']};d.update(verdict=verdict,rationale=reason,packetIndex=n)
   if len(parts)>3:d['proposedTarget']=parts[3]
   f.write(json.dumps(d,ensure_ascii=False)+'\n')
print('Recorded',len(existing))
