# Adjudicate the complete independent findings

The coordinator reconciles all version-bound judgments and required context,
adjudicates objective findings against canonical source/glossary/consumer evidence,
then applies one consolidated repair batch to the owning locale. Build/check
changed resources and prepare the exact correction delta for independent review.
Do not automatically launch another model or accept unread/source/native gates.
