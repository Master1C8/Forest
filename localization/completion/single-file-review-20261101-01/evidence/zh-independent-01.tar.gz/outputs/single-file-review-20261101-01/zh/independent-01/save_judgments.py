import json,sys
from pathlib import Path
from read_review import BASE, ROWS

out=BASE/'judgments.jsonl'
existing={json.loads(s)['id'] for s in out.read_text().splitlines()} if out.exists() else set()
groups=json.load(sys.stdin)
new=[]
for group in groups:
    indices=group.pop('indices',None)
    if indices is None:
        start,stop=group.pop('explicitlyJudgedRange')
        indices=list(range(start,stop))
    assert group.get('verdict') and group.get('rationale')
    for i in indices:
        r=ROWS[i]
        assert r['id'] not in existing, r['id']
        existing.add(r['id'])
        new.append(dict(group,id=r['id'],sourceSha256=r['sourceSha256'],targetSha256=r['targetSha256'],readingIndex=i))
with out.open('a') as f:
    for r in new: f.write(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n')
print(json.dumps({'saved':len(new),'total':len(existing)}))
