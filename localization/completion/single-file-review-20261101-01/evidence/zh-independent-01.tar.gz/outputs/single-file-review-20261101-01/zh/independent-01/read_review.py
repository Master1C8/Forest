import json, sys
from pathlib import Path

BASE = Path(__file__).parent
HANDOFF = Path('localization/editorial-delivery/zh-single-file-20261101-01')
ROWS = [json.loads(s) for s in (HANDOFF/'independent-scope/review-packet.jsonl').read_text().splitlines()]
CONTEXT = {r['id']: r for r in [json.loads(s) for s in (HANDOFF/'review-context.jsonl').read_text().splitlines()]}

def show(start, stop):
    seen_path=BASE/'displayed-context-definitions.json'
    seen = set(json.loads(seen_path.read_text())) if seen_path.exists() else set()
    for i in range(start, stop):
        r = ROWS[i]
        c = CONTEXT[r['id']]
        assert all(r.get(k) == v for k,v in c.items())
        out = {'i':i,'id':r['id'] if r['id'].startswith('ds:') else r['id'].split('.bundle:')[-1],'s':r['source'],'t':r['target']}
        if 'sourceTopology' in r:
            out['dialogue'] = r['dialogueContext']
            topo = r['sourceTopology']
            conv = json.dumps(topo['conversationFields'],ensure_ascii=False)
            if conv not in seen:
                out['conversationFields'] = topo['conversationFields']; seen.add(conv)
            e=topo['entry']
            defaults={'conditionPriority':2,'conditionsString':'','delaySimStatus':0,'falseConditionAction':'Block','isGroup':0,'isRoot':0,'nodeColor':'','onExecute':{'m_PersistentCalls':{'m_Calls':[]}},'userScript':''}
            out['entry']={k:v for k,v in e.items() if k not in ('canvasRect','fields','id','conversationID','outgoingLinks') and (k not in defaults or v!=defaults[k])}
            out['links']=[[v['destinationConversationID'],v['destinationDialogueID'],v['priority'],v['isConnector']] for v in e['outgoingLinks']]
            out['entryFields']={f['title']:f['value'] for f in e['fields'] if f['title']!='Dialogue Text' and f['value'] not in ('','[]')}
        if 'galleryConsumerContext' in r:
            g=r['galleryConsumerContext']
            # Semantic contracts are retained. Digests/identity selectors remain in originals.
            out['gallery']={}
            for k,v in g.items():
                if k in ('id','source','sourceSpan','sourceUtf8Sha256','sourceValueSha256','contextCellIds','applicationSelector','consumerMethods','reuseCandidateIndexes'): continue
                rep=json.dumps([k,v],ensure_ascii=False,sort_keys=True)
                if rep in seen: continue
                out['gallery'][k]=v; seen.add(rep)
        print(json.dumps(out,ensure_ascii=False,separators=(',',':')))
    seen_path.write_text(json.dumps(sorted(seen),ensure_ascii=False))

if __name__=='__main__':
    show(int(sys.argv[1]),int(sys.argv[2]))
