"""Deterministic immutable handoff preparation. This code creates no judgments."""
import json,pathlib,sys,hashlib,re,collections
sys.path.insert(0,str(pathlib.Path('tools').resolve()))
from forest_localization.core import encode
from locale_review_work import prepare_scope
ROOT=pathlib.Path('.').resolve();OUT=ROOT/'localization/editorial-delivery/zh-single-file-20261101-01';IMP=ROOT/'localization/language-imports/zh-20261101';RUN=ROOT/'outputs/single-file-parallel-20261101-01/zh/author-01'
cache={}
def pin(p):
 p=pathlib.Path(p);p=p if p.is_absolute() else ROOT/p
 if str(p) not in cache:
  raw=p.read_bytes();cache[str(p)]=dict(path=str(p.relative_to(ROOT)),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
 return cache[str(p)]
def read(p):return json.loads(pathlib.Path(p).read_text())
def sha(s):return hashlib.sha256(s.encode()).hexdigest()
def dump(name,obj):
 p=OUT/name
 if p.exists():raise RuntimeError('Immutable handoff output occupied: '+str(p))
 p.write_bytes(encode(obj));return pin(p)
def lines(name,rows):
 p=OUT/name
 with p.open('x') as f:
  for r in rows:f.write(json.dumps(r,ensure_ascii=False,sort_keys=True)+'\n')
 return pin(p)
doc=read(ROOT/'localization/languages/zh.json');translations=doc['translations'];catalog=read(ROOT/'localization/framework/forest045-shared-v2/catalog.json');order=[r['id'] for r in catalog];bycat={r['id']:r for r in catalog};assert set(order)==set(translations) and len(order)==14606
pres=read(ROOT/'localization/completion/single-file-parallel-20261101-01/shared/source-preservation.json')['baselinePreserved']
assert all(translations[i]['source']==bycat[i]['source'] for i in order)
assert all(sha(translations[i]['source'])==h and translations[i]['target']==translations[i]['source'] for i,h in pres.items())
assert all(isinstance(r['target'],str) for r in translations.values())
protected=[dict(id=i,sourceSha256=pres[i],targetSha256=sha(translations[i]['target']),exact=True,semanticPassAdded=False) for i in order if i in pres]
lines('protected-value-comparison.jsonl',protected)
dump('protected-summary.json',dict(count=len(protected),passed=True,scope='Complete 1781 source-preservation targets plus catalog source equality for all14606; remaining engine grammar/resource protections are checked by the compiler',input=pin(ROOT/'localization/completion/single-file-parallel-20261101-01/shared/source-preservation.json')))
# Verify immutable archival content once. These remain preliminary verdicts.
archive=ROOT/'localization/editorial-delivery/zh-cycle-02';idx=read(archive/'archive-index.json');assert pin(archive/'archive-index.json')['sha256']==read(ROOT/'localization/editorial-delivery/zh-current.json')['evidence']['indexSha256']
for v in idx['files'].values():assert pin(ROOT/v['archive'])['sha256']==v['sha256']
assert pin(archive/'initial-semantic-reviews.jsonl')['sha256']==idx['initialSemanticReviewsSha256']
receipts=collections.defaultdict(list)
for name in ['initial-semantic-reviews.jsonl','prior-independent/reviews.jsonl','independent-delta/reviews.jsonl']:
 p=archive/name
 for l in p.open():
  r=json.loads(l);receipts[r['id']].append((pin(p),r))
retained=[];unmatched=[]
for i in order:
 if not i.startswith('ds:') or i in pres:continue
 row=translations[i];matches=[(p,r) for p,r in receipts[i] if r.get('sourceSha256')==sha(row['source']) and r.get('targetSha256')==sha(row['target']) and r.get('verdict') in ['pass','clean']]
 if matches:
  p,r=matches[0];retained.append(dict(id=i,sourceSha256=sha(row['source']),targetSha256=sha(row['target']),evidence=p,originalJudgment=r,scope='retained preliminary source-to-target evidence; no upgrade to full-game acceptance'))
 else:unmatched.append(i)
lines('retained-preliminary-judgments.jsonl',retained)
dump('unmatched-prior-dialogue.json',dict(ids=unmatched,count=len(unmatched),status='fresh author pair reading; independent judgment remains pending'))
observations=read(OUT/'primary-observations.json');fresh_convos=set(observations['freshDialogueConversationsRead'])
dialogue={r['id']:r for r in [json.loads(l) for l in (ROOT/'localization/zh-assets/dialogue.zh.jsonl').open()]}
# Only the original topology is authoritative. Saved translated row metadata supplies
# stable pointers and consumer names, never operational instructions.
original=read(ROOT/'assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json');topology={}
for c in original['conversations']:
 for e in c['dialogueEntries']:topology[(int(c['id']),int(e['id']))]=dict(conversationFields=c['fields'],entry=e)
fresh=set(i for i,r in dialogue.items() if r['conversationId'] in fresh_convos)|set(unmatched)
fresh|={i for i in order if not i.startswith('ds:')}
fresh-=set(pres)
page_manifest=read(IMP/'dialogue-primary-pages/manifest.json')
progress=read(IMP/'dialogue-primary-pages/reading-progress.json')
assert progress['completedPages']==list(range(40)) and progress['nextPage'] is None
page_ids=set()
for page in page_manifest:
 contents=[json.loads(line) for line in (ROOT/page['path']).open()]
 assert [r['id'] for r in contents]==page['ids'] and len(contents)==page['count']
 for row in contents:
  assert row['source']==translations[row['id']]['source'] and row['target']==translations[row['id']]['target']
  assert row['id'] not in page_ids
  page_ids.add(row['id'])
 pin(ROOT/page['path'])
fresh|=page_ids
assert fresh==set(order)-set(pres), 'Fresh primary reading has an exact uncovered unit'
# A transfer ledger has evidence categories, never generated pass verdicts.
coverage=[]
for i in order:
 row=translations[i]
 kind='source-preservation-only' if i in pres else ('fresh-author-pair-reading' if i in fresh else 'retained-preliminary-pair-judgment')
 coverage.append(dict(id=i,sourceSha256=sha(row['source']),targetSha256=sha(row['target']),evidenceKind=kind,independentAcceptance='not-added-by-this-task'))
lines('primary-evidence-ledger.jsonl',coverage)
dump('primary-coverage.json',dict(total=14606,freshAuthorPairIds=[i for i in order if i in fresh],freshAuthorPairCount=len(fresh),retainedPreliminaryOnlyIds=[i for i in order if i not in fresh and i not in pres],retainedPreliminaryOnlyCount=sum(i not in fresh and i not in pres for i in order),exactPreservationCount=len(pres),pairEvidenceUnaccountedIds=[i for i in order if i not in fresh and i not in pres and i not in {r['id'] for r in retained}],freshFullOrdinaryCorpusReread=True,currentWholeGameSemanticAcceptance=False,independent='pending',boundary='Fresh author source/target reading covers every ordinary unit. The1781 exact source-preserved values have separate deterministic comparison. Archived judgments remain preliminary; no independent or native acceptance is added.'))
changes=read(IMP/'authored-and-resolved-83.json')+read(IMP/'empty-tail-span-repair.json')+[read(IMP/'timing-repair.json')]
assert len(changes)==90 and len({r['id'] for r in changes})==90
for r in changes:assert translations[r['id']]['source']==r['source'] and translations[r['id']]['target']==r['target']
changed={r['id'] for r in changes};primary=changed|set(unmatched)
# Mandatory regressions enumerate exact selected surfaces, separate from source-only
# controls and the native-dependent font/loading/layout predicates.
regression=set(i for i in order if i.startswith('level1:') or i.startswith('managed:') or i.startswith('StreamingAssets/') or 'INVENTORY' in translations[i]['source'])
gallery={r['id']:r for r in [json.loads(l) for l in (ROOT/'localization/source/gallery-chapter-display-20261028/admission-v1/consumer-context.jsonl').open()]}
for i,r in gallery.items():
 if i in translations:assert r['source']==translations[i]['source'] and sha(r['source'])==r['sourceUtf8Sha256'];regression.add(i)
bell_rows=[json.loads(l) for l in (ROOT/'localization/zh-assets/completion/repair-bell-notifications72-v1/targets.jsonl').open()]
regression|={r['id'] for r in bell_rows if r['id'] in translations}
regression|={i for i,r in dialogue.items() if r['conversationId'] in {139,169,382,138,198,199,409,422,569} or '/topOrBottom' in r['conversation']}
haiku_sources={'We molded the Earth','Busy little bug','Oh lovely Falcon','Across the raging waters','What is important to you?','Take me high above the clouds','To unite our friends','Why must you work now?','Where no one has gone'}
regression|={i for i in order if translations[i]['source'] in haiku_sources}
regression-=set(pres)
source_set={translations[i]['source'] for i in primary};repeats={i for i in order if i not in pres and translations[i]['source'] in source_set}
containing_convos={dialogue[i]['conversationId'] for i in primary if i in dialogue};exchange={i for i,r in dialogue.items() if r['conversationId'] in containing_convos and i not in pres}
selected=primary|regression|repeats|exchange
components={'changed-ids':[i for i in order if i in changed],'primary-ids':[i for i in order if i in primary],'mandatory-regressions':[i for i in order if i in regression],'exact-repetitions':[i for i in order if i in repeats],'containing-exchanges':[i for i in order if i in exchange],'closure-ids':[i for i in order if i in selected],'source-preservation-ids':[i for i in order if i in pres]}
for name,ids in components.items():
 with (OUT/(name+'.txt')).open('x') as f:f.write(''.join(i+'\n' for i in ids))
rows=[]
for i in order:
 r=translations[i];row=dict(id=i,**r,sourceSha256=sha(r['source']),targetSha256=sha(r['target']),selectors=bycat[i]['selectors'])
 if i in dialogue:
  q=dialogue[i];row['dialogueContext']={k:q[k] for k in ['actorId','conversantId','conversation','conversationId','entryId']};row['sourceTopology']=topology[(int(q['conversationId']),int(q['entryId']))]
 if i in gallery:row['galleryConsumerContext']=gallery[i]
 rows.append(row)
lines('full-current-packet.jsonl',rows)
lines('authored-review-primary.jsonl',[r for r in rows if r['id'] in primary])
evidence=pin(IMP/'prepare_handoff.py');causes=[dict(id=i,reason='Concrete containing-exchange, exact repetition or mandatory-regression membership from the pinned reproducible selector; source-only preserved IDs excluded.',causedBy=components['changed-ids'],evidence=evidence) for i in order if i in selected and i not in primary]
lines('dependencies.jsonl',causes)
scope=prepare_scope(ROOT,OUT/'full-current-packet.jsonl',OUT/'authored-review-primary.jsonl',OUT/'independent-scope',causes)
dump('handoff-manifest.json',dict(locale='zh',culture='zh-CN',language=pin(ROOT/'localization/languages/zh.json'),changes=len(changed),primary=len(primary),closure=len(selected),sourceOnlyContext=len(rows)-len(selected),retainedPreliminary=len(retained),freshPrimaryPairReading=len(fresh),protected=len(pres),components={name:pin(OUT/(name+'.txt')) for name in components},inputs=list(cache.values()),independentAcceptance='pending; no nested reviewer launched',native='not-run',runtime='not-run',release='not-accepted',limitations=['Full fresh author proofreading is complete; prior matching preliminary judgments remain explicitly preliminary and are not current whole-game independent acceptance.','Font face coverage and compiled bytes do not establish coherent native metrics, dynamic atlas allocation, fallback selection, actual loading or fit.','Owner-deferred human NSFW glossary review is unchanged.']))
print(json.dumps(dict(changed=len(changed),primary=len(primary),closure=len(selected),freshReadIds=len(fresh),retainedPreliminary=len(retained),unmatched=len(unmatched))))
