# Simplified Chinese single-file author delivery

The authoritative locale file is `localization/languages/zh.json`, culture `zh-CN`, using the unchanged `forest045-shared-v2` compiler. The exact final file, source/control preservation, primary reading and pending independent review are bound by `localization/editorial-delivery/zh-single-file-20261101-01/`.

The import records retain exact source/target origins. `authored-and-resolved-83.json` records recovered/authored missing targets and resolved version conflicts; `empty-tail-span-repair.json` records six empty tail wrappers removed without visible text loss; `timing-repair.json` records the elapsed-time correction. Historical overlays and drafts remain unchanged. Do not rerun the one-time authoring scripts against a completed file; their expected-before assertions deliberately reject the new state.

Primary proofreading read all12825 ordinary wording IDs, including all40 remaining dialogue pages and complete separately selected risk conversations. The778 losslessly grouped non-dialogue pairs retain all2360 membership IDs. The1781 source-preserved values have exact comparison proof and are separate from translated semantic coverage. No old review is upgraded into whole-game acceptance.

The unmodified pinned Noto Sans CJK SC Regular face is embedded once and bound to eight registered ordinary font roles. The final ordinary corpus has2316 characters with no missing cmap entries. Fictional-language mapping is unchanged. Static coverage and resource readback do not establish native loading, fallback, dynamic atlas allocation, shaping or layout fit.

The parent owns independent review and Git integration. No nested model, old queue, game, GUI, screenshot, installer, publication, deployment or server action was performed. See the phase-owned `outputs/single-file-parallel-20261101-01/zh/author-01/result.json` for the final build/check and usage cutoff.
