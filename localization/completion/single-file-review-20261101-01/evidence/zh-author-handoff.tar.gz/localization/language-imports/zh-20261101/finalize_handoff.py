"""Finalize the completed zh author phase; never launch work or alter locale bytes."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/antonkrutov/Desktop/Forest')
RUN = ROOT / 'outputs/single-file-parallel-20261101-01/zh/author-01'
HANDOFF = ROOT / 'localization/editorial-delivery/zh-single-file-20261101-01'
EXPECTED = 'c68dee191f1556f65ea9cb614fd87487e4a6911f01c77116ce4d24db5ee5cc34'


def load(path):
    return json.loads(path.read_text())


def pin(path):
    return {'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=True, indent=2, sort_keys=True) + '\n')


def main():
    now = datetime.datetime.now(datetime.timezone.utc).isoformat()
    language = pin(ROOT / 'localization/languages/zh.json')
    assert language['sha256'] == EXPECTED
    entries = load(ROOT / language['path'])['translations']
    assert len(entries) == 14606 and all(isinstance(r['target'], str) for r in entries.values())
    checks = {}
    for name in ['build-final.log', 'check-final.log']:
        rows = [json.loads(line) for line in (RUN / name).read_text().splitlines() if line.startswith('{')]
        assert len(rows) == 1, (name, 'missing or ambiguous result')
        result = rows[0]
        assert result['passed'] is True and result['locale'] == 'zh'
        assert result['units'] == 14606 and result['resources'] == 16
        assert result['configuredFontRoles'] == 8 and result['installed'] is False
        assert result['newModelRequests'] == 0
        checks[name] = {'receipt': pin(RUN / name), 'result': result}
    task = load(RUN / 'task.json')
    for path, expected in task['job']['immutablePins'].items():
        assert pin(ROOT / path)['sha256'] == expected, path
    manifest = load(HANDOFF / 'handoff-manifest.json')
    refs = manifest['inputs'] + list(manifest['components'].values())
    for ref in refs:
        assert pin(ROOT / ref['path']) == ref, ref['path']
    artifact = load(RUN / 'artifact-verification.json')
    artifact_root = ROOT / artifact['artifact']
    assert pin(artifact_root / 'manifest.json')['sha256'] == artifact['manifestSha256']
    for ref in artifact['resources']:
        actual = pin(artifact_root / ref['path'])
        assert actual['sha256'] == ref['sha256'] and actual['bytes'] == ref['bytes'], ref['path']
    assert artifact['passed'] and artifact['languageSha256'] == EXPECTED
    handoff_check = load(RUN / 'handoff-verification.json')
    assert handoff_check['passed'] and handoff_check['newIndependentVerdicts'] == 0
    assert pin(ROOT / handoff_check['requiredConsumerContext']['path'])['sha256'] == handoff_check['requiredConsumerContext']['sha256']
    binding = load(HANDOFF / 'primary-reading-binding.json')
    assert binding['language'] == language and binding['primaryUnreadIds'] == []
    assert binding['freshOrdinaryPrimaryIds'] == 12825
    for ref in binding['readFiles']:
        assert pin(ROOT / ref['path']) == ref, ref['path']
    evidence = [pin(HANDOFF / name) for name in [
        'handoff-manifest.json', 'REVIEW.md', 'review-context.jsonl',
        'primary-reading-binding.json', 'independent-scope/scope.json',
        'independent-scope/review-packet.jsonl', 'independent-scope/source-context.jsonl']]
    final = {'timestamp': now, 'passed': True, 'language': language,
             'taskPinsVerified': len(task['job']['immutablePins']),
             'handoffReferencesVerified': len(refs), 'resourceFilesVerified': 16,
             'compiler': checks, 'evidence': evidence,
             'boundary': 'Exact static artifact and author evidence only; no independent/native/release acceptance.'}
    save(RUN / 'final-verification.json', final)
    checklist = load(RUN / 'acceptance-checklist.json')
    checklist[1].update(status='build-and-check-passed',
                        currentEvidence='build-final.log, check-final.log, artifact-verification.json and final-verification.json; exact final language and 16 delivered resource hashes match.',
                        uncertainty='No game execution or native acceptance.',
                        nextPermittedAction='Parent reconciles immutable independent editorial handoff; native validation needs applicable owner instruction.')
    save(RUN / 'acceptance-checklist.json', checklist)
    runtime = load(RUN / 'runtime-verification.json')
    session = Path(runtime['sessionMetadataPath'])
    with session.open('rb') as stream:
        stream.seek(max(0, session.stat().st_size - 2 * 1024 * 1024))
        tail = stream.read().splitlines()
    usage = None
    for raw in tail:
        try:
            row = json.loads(raw)
        except (ValueError, UnicodeDecodeError):
            continue
        payload = row.get('payload', {})
        total = (payload.get('info') or {}).get('total_token_usage')
        if row.get('type') == 'event_msg' and payload.get('type') == 'token_count' and total:
            usage = {'cutoff': row.get('timestamp'), 'tokens': total}
    assert usage is not None, 'Measured telemetry required; do not invent zeros.'
    usage.update(sessionId=runtime['threadId'], model='gpt-6.1-sol', reasoning='high', provider='openai',
                 scope='Fresh CLI worker cumulative usage; includes failed/read-only attempts and all author work before cutoff.',
                 baseline='Fresh exec/null parent; no inherited session usage.',
                 nestedModelsOrAgentsLaunched=0,
                 parentOrchestrationTokens='unknown; outside this worker session',
                 reportingTail='Unmeasured requests after cutoff and platform overhead; current report cannot measure itself.',
                 subsetRules='Cached input is a subset of input; reasoning output is a subset of output. Neither is added twice.')
    save(RUN / 'usage.json', usage)
    result = {'status': 'review-ready', 'stage': 'author-primary-static-complete', 'locale': 'zh', 'culture': 'zh-CN',
              'timestamp': now, 'runtimeVerification': pin(RUN / 'runtime-verification.json'),
              'language': language, 'entries': 14606, 'nullTargets': 0,
              'primary': {'role': 'author/editor; not independent', 'ordinarySourceTargetRead': 12825,
                          'unreadIds': [], 'protectedExactSourceValues': 1781,
                          'protectedSummary': pin(HANDOFF / 'protected-summary.json'),
                          'protectedComparison': pin(HANDOFF / 'protected-value-comparison.jsonl'),
                          'newOrResolvedRows': 90, 'readingBinding': pin(HANDOFF / 'primary-reading-binding.json')},
              'artifact': {'path': artifact['artifact'], 'manifest': pin(artifact_root / 'manifest.json'),
                           'resourceFiles': 16, 'installed': False, 'verification': pin(RUN / 'artifact-verification.json')},
              'compiler': checks, 'finalVerification': pin(RUN / 'final-verification.json'),
              'independentReview': {'status': 'pending', 'primaryIds': 123, 'requiredReviewIds': 1712,
                                    'sourceOnlyContextIds': 12894, 'newIndependentVerdicts': 0,
                                    'retainedMatchingPreliminaryReceipts': 10424,
                                    'wholeGameIndependentAcceptance': False,
                                    'requiredEvidence': evidence,
                                    'limits': 'Read all selected source/target/context IDs. Source-only context and archived preliminary evidence do not pass unselected targets.'},
              'font': {'status': 'static-corpus-coverage-passed; native-pending', 'roles': 8,
                       'corpusCharacters': 2316, 'missingCmapCharacters': 0,
                       'verification': pin(RUN / 'font-final-verification.json')},
              'remainingGates': {'independent': 'pending', 'native': 'not-run', 'runtime': 'not-run',
                                 'nativeFontsAndLayout': 'not-accepted', 'humanNSFWGlossary': 'deferred-unchanged',
                                 'release': 'not-accepted', 'git': 'not-performed; parent-owned'},
              'acceptanceChecklist': pin(RUN / 'acceptance-checklist.json'), 'usage': pin(RUN / 'usage.json'),
              'nextPermittedAction': 'Parent coordinates version-matching independent review using the 123 primary / 1712 required IDs with mandatory review-context.jsonl; this result launches no process.',
              'restrictedActionsPerformed': [],
              'preservedHistory': 'Old queues, drafts, superseded build and preliminary receipts retained unchanged.'}
    save(RUN / 'result.json', result)
    checkpoint = load(RUN / 'checkpoint.json')
    checkpoint.update(status='review-ready', timestamp=now,
                      nextPermittedAction=result['nextPermittedAction'], result=pin(RUN / 'result.json'))
    checkpoint['activeCheck']['status'] = 'passed'
    checkpoint['activeCheck']['receipt'] = pin(RUN / 'check-final.log')
    save(RUN / 'checkpoint.json', checkpoint)
    print(json.dumps({'status': 'review-ready', 'languageSha256': EXPECTED,
                      'build': 'passed', 'check': 'passed', 'usage': usage}))


if __name__ == '__main__':
    main()
