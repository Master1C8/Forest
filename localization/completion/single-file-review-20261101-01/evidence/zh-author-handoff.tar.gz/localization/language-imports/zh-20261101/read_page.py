"""Compact lossless source/target reader; supplies no judgments."""
import json,pathlib,sys
root=pathlib.Path(__file__).parent/'dialogue-primary-pages';prev=None
for arg in sys.argv[1:]:
 n=int(arg);print('PAGE',n)
 for l in (root/('page-%02d.jsonl'%n)).open():
  r=json.loads(l)
  if r['conversation']!=prev:print('#',r['conversation']);prev=r['conversation']
  print(json.dumps([r['id'],r['actor']+'>'+r['to'],r['source'],r['target']],ensure_ascii=False,separators=(',',':')))
