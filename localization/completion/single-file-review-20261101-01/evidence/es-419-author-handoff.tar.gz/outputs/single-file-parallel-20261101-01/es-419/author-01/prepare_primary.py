import json,collections,hashlib,sys
from pathlib import Path
sys.path.insert(0,'tools');from forest_localization.core import encode
b=Path('outputs/single-file-parallel-20261101-01/es-419/author-01');j=json.loads(Path('localization/languages/es-419.json').read_text()); groups=collections.defaultdict(list)
for i,r in j['translations'].items():
 if not i.startswith('ds:'):groups[(r['source'],r['target'])].append(i)
rows=[dict(group=n,ids=ids,source=s,target=t) for n,((s,t),ids) in enumerate(groups.items())]
(b/'primary-nondialogue-groups.json').write_bytes(encode(rows))
print('groups',len(rows),'occurrences',sum(len(r['ids']) for r in rows))
