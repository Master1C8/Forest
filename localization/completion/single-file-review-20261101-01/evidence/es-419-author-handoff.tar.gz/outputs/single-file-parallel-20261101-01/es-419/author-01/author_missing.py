import json,sys,hashlib
from pathlib import Path
sys.path.insert(0,'tools')
from forest_localization.core import encode
root=Path('outputs/single-file-parallel-20261101-01/es-419/author-01')
p=Path('localization/languages/es-419.json');j=json.loads(p.read_text())
wording={
'(Usable)':'(Utilizable)',
"A box of Finley's stuff he left with his old roommates. Looks like some papers, paintbrushes, and a few bedroom toys.":'Una caja con cosas de Finley que dejó con quienes antes compartían casa con él. Parece contener papeles, pinceles y unos cuantos juguetes sexuales.',
'A special friendship cookie for Finley to help his old roommates make amends. The icing spells out "We\'re Sorry".':'Una galleta especial de amistad para Finley, para ayudar a quienes antes compartían casa con él a hacer las paces. El glaseado dice «Lo sentimos».',
'Say hi to the bunny.':'Saluda a la coneja.',
'Play':'Jugar','Start New Game':'Iniciar partida nueva','Report a Bug':'Reportar un error','Options\n':'Opciones\n','Gallery':'Galería',
'Mia (Meerkat)':'Mia (Suricata)','Bat':'Murciélago','Mouse (Whiskers)':'Ratón (Bigotes)','Otter Gal':'Chica nutria','Otter Gal 2':'Chica nutria 2','Poppy (Mouse)':'Poppy (Ratón)','Prairie Dog':'Perrito de la pradera','Ruby (Cardinal)':'Ruby (Cardenal)','Sable (Bat)':'Sable (Murciélago)','Bear 1':'Oso 1','Bear 2':'Oso 2','Becka':'Becka','Blue Bird':'Pájaro azul','Ashe (Chinchilla)':'Ashe (Chinchilla)','Cardinal':'Cardenal','Chinchilla':'Chinchilla','Everyone':'Todos','Hedgehog':'Erizo','Horse Gal':'Chica yegua','Meerkat':'Suricata',
'Hey Rascal!':'¡Oye, Rascal!','Completed':'Completadas','Active':'Activas','Run Cheat?':'¿Ejecutar truco?','Activated':'Activado',
'When critters are “on a date” – They won’t be able to do Quests, OR gossips. You will need to locate them in their normal locations for that. Besides… it would be quite rude to bother them during their date!':'Cuando las criaturas están «en una Cita», no estarán disponibles para misiones ni Chismes. Para eso tendrás que buscarlas en sus ubicaciones habituales. Además… ¡sería muy descortés molestarlas durante su Cita!',
'The Critters of the area are inspired by your promiscuity! Occasionally, critters will show up in pairs by Maverick’s Shop and be hanging out! Be sure to talk with them and see how they are doing!':'¡Tu promiscuidad inspira a las criaturas de la zona! De vez en cuando, aparecerán en parejas junto a la tienda de Maverick para pasar el rato. ¡No olvides hablar con ellas para ver cómo están!',
'Dates are unlocked over time. Some may require certain quests or gossips to unlock. Some dates will continue over multiple meets!':'Las Citas se desbloquean con el tiempo. Algunas pueden requerir ciertas misiones o Chismes para desbloquearse. ¡Algunas Citas continúan a lo largo de varios encuentros!'
}
rows=[]
for i,r in j['translations'].items():
 if r['target'] is None:
  assert r['source'] in wording, i
  target=wording[r['source']];rows.append(dict(id=i,source=r['source'],expectedBefore=None,target=target,sourceSha256=hashlib.sha256(r['source'].encode()).hexdigest(),targetSha256=hashlib.sha256(target.encode()).hexdigest(),authorThreadId='01a1935d-ff41-7912-9c06-55bf930b5b9e',independentAcceptance='pending'))
  r['target']=target
(root/'authored-missing.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows))
p.write_bytes(encode(j));(root/'complete-before-primary.json').write_bytes(encode(j))
print(json.dumps({'authoredOccurrences':len(rows),'distinctSources':len({r['source'] for r in rows}),'remainingNull':sum(r['target'] is None for r in j['translations'].values())}))
