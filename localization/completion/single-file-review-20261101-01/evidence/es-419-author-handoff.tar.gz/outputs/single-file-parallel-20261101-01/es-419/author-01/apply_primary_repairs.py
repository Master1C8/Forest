import json,sys,hashlib,collections
from pathlib import Path
sys.path.insert(0,'tools');from forest_localization.core import encode
b=Path('outputs/single-file-parallel-20261101-01/es-419/author-01');p=Path('localization/languages/es-419.json');doc=json.loads(p.read_text()); t=doc['translations'];changes=[]
def edit(i,target,reason):
 old=t[i]['target']
 if old==target:return
 changes.append(dict(id=i,source=t[i]['source'],expectedBefore=old,target=target,reason=reason,sourceSha256=hashlib.sha256(t[i]['source'].encode()).hexdigest(),previousTargetSha256=hashlib.sha256(old.encode()).hexdigest(),targetSha256=hashlib.sha256(target.encode()).hexdigest()))
 t[i]['target']=target
# Exact authored owner wins over generic source-only migration.
for line in Path('localization/es-419-assets/remaining112-0076.authored.jsonl').open():
 r=json.loads(line)
 if r['source']=='Mouse':
  assert t[r['id']]['source']==r['source'] and r['target']=='Ratón'
  edit(r['id'],r['target'],'Restore exact own authored neutral forest-mouse caption; generic Mouse matching had imported Mabel-specific Ratona.')
for i,r in t.items():
 if i.startswith('managed:') and r['source']=='Mouse':edit(i,'Ratón','Generic speaker display can refer to unknown mice; use the approved neutral species label instead of female Mabel agreement.')
# Each copied bell title is resolved from its exact consumer hierarchy.
for line in Path('localization/es-419-assets/ornamental569.authored.jsonl').open():
 r=json.loads(line);i=r['id']
 if i not in t:continue
 source=t[i]['source'];root=r.get('hierarchy','').split('/')[0]
 color={'PurpleBellItemNotification':('<size=22>M</size>ORADA'),'RedBellItemNotification':('<size=22>R</size>OJA'),'GreenBellItemNotification':('<size=22>V</size>ERDE')}.get(root)
 if source=='<size=22>T</size>HE <size=22>B</size>LUE <size=22>B</size>ELL' and color:
  edit(i,'<size=22>L</size>A <size=22>C</size>AMPANA '+color,'Copied BLUE source: actual notification hierarchy determines purple/red/green bell identity; retain all face/glow copies.')
 if root.endswith('BellItemNotification') and source.startswith('<size=22></size>HE'):
  edit(i,t[i]['target'].replace('<size=22></size>','',1),'Remove empty styling span from suffix layer; separate leading L layer remains exact, assembling LA CAMPANA plus its source-bound color.')
# Direct author wording: current es-419 glossary keeps top/bottom distinct from dominance.
new={
'176:151':'[pic=2]¡Soy lo que llaman un bottom!',
'200:134':'[pic=4]Ah, je, ¡soy bottom de pies a cabeza!',
'207:133':'[pic=2]Ah, ¡yo sí que soy bottom!',
'208:134':'[pic=2]¡Los dos!',
'214:135':'[pic=2]Incluso cuando soy «top», lo hago con suavidad y cariño.',
'214:137':'[pic=1]Aunque, si le preguntas a mi esposa, te dirá que soy bottom, sin duda, ¡ja!',
'224:136':'[pic=6]Por mi tamaño y mis «características singulares», la mayoría de las criaturas prefieren que yo sea el top.',
'226:134':'[pic=3]¡Creo que soy más bien bottom!',
'226:137':'[pic=1]¡Pero no sé si las palabras tradicionales «top y bottom» se aplican en esos casos!',
'230:137':'[pic=5]Pero en serio, la mayor parte del tiempo soy top.',
'237:137':'[pic=1]¿Con alguien de mi tamaño, en cambio? Entonces es más probable que yo sea el top.',
'238:134':'[pic=4]Oh, supongo que suelo ser el top…',
'238:136':'[pic=4]¡Aunque no me opondría a ser bottom!',
'331:583':'[pic=4]Dime, ¿te sientes cómodo siendo quien recibe?',
'376:151':'[pic=4]Je, bueno, la verdad es que siempre he querido ser el bottom de un semental grande y fornido alguna vez…',
'376:153':'¿Dijiste que querías ser bottom?',
'393:400':'[pic=5]¡Oye! ¿Por qué siempre soy el bottom?',
'393:401':'[pic=3]¡Puedo ser top!',
'393:403':'[pic=2]¿Qué? ¿Un pequeñín como tú de top? ¿Estás loco?',
'393:405':'[pic=2]¡Claro que puedo ser top!',
'455:747':'Si la próxima vez quieres ser top, avísame.',
'571:806':'[pic=2]Bueno, ¿no es mi única opción ser bottom? No tengo… una cosa de esas…',
'571:811':'Exacto, porque hay bottoms que llevan el control,\nque generan el poder desde…',
'577:780':'[pic=4]¡En el fondo soy una bottom que lleva el control!',
'583:781':'[pic=3]La mayor parte del tiempo soy top.',
'583:782':'[pic=4]He sido bottom un par de veces… Estuvo… bien.'
}
for key,target in new.items():edit('ds:'+key+':Dialogue Text',target,'Apply current es-419 top/bottom glossary without equating sexual position with dominance/submission; preserve the full source unit and speaker role.')
for i,r in t.items():
 if r['source'] in ['Top or bottom?','Top or Bottom?']:edit(i,'¿Top o bottom?','Apply approved es-419 role labels uniformly; the English question is the same across speakers.')
 if r['source']=='Bottom':edit(i,'Bottom','Apply current es-419 glossary term in the Bio role label.')
(b/'primary-repairs.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in changes))
(b/'final-candidate.json').write_bytes(encode(doc));p.write_bytes(encode(doc))
print(json.dumps({'repairs':len(changes),'reasons':dict(collections.Counter(r['reason'] for r in changes))}))
