import json,hashlib
from pathlib import Path
B=Path('outputs/single-file-parallel-20261101-01/es-419/author-01');E=Path('localization/editorial-delivery/es-419-single-file-20261101-01')
j=json.loads(Path('localization/languages/es-419.json').read_text());T=j['translations'];read={json.loads(l)['id'] for l in (E/'primary-wording-read.jsonl').open()};pres=json.loads(Path('localization/completion/single-file-parallel-20261101-01/shared/source-preservation.json').read_text())['baselinePreserved'];ds=[json.loads(l) for l in Path('localization/es-419-assets/dialogue.es-419.jsonl').open()]
tree=json.loads(Path('assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json').read_text());nodes={(c['id'],n['id']):n for c in tree['conversations'] for n in c['dialogueEntries']};p=B/'dialogue-primary-pages';p.mkdir(exist_ok=True);pages=[];lines=[];ids=[];size=0
for r in ds:
 i=r['id']
 if i in read or i in pres:continue
 n=nodes[(r['conversationId'],r['entryId'])]; q=T[i]
 out=[i.removeprefix('ds:').removesuffix(':Dialogue Text'),r['actorId']+'>'+r['conversantId'],q['source'],q['target'],[str(e['destinationConversationID'])+':'+str(e['destinationDialogueID']) for e in n['outgoingLinks']]]
 if n['conditionsString']:out.append({'condition':n['conditionsString']})
 text=json.dumps(out,ensure_ascii=False,separators=(',',':'))+'\n'
 if size+len(text)>33000 and lines:
  k=len(pages);f=p/f'{k:03d}.txt';f.write_text(''.join(lines));pages.append(dict(page=k,path=str(f),ids=ids,sha256=hashlib.sha256(f.read_bytes()).hexdigest()));lines=[];ids=[];size=0
 lines.append(text);ids.append(i);size+=len(text)
if lines:
 k=len(pages);f=p/f'{k:03d}.txt';f.write_text(''.join(lines));pages.append(dict(page=k,path=str(f),ids=ids,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(p/'index.json').write_text(json.dumps(pages,indent=2)+'\n');print('pages',len(pages),'unread-wording',sum(len(x['ids']) for x in pages))
