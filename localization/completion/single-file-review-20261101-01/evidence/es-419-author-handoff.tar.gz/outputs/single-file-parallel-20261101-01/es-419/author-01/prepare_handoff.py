"""Deterministic bindings, origin recovery and review packet preparation. No judgments generated."""
import json,hashlib,re,sys,collections,itertools,datetime
from pathlib import Path
sys.path.insert(0,'tools')
from forest_localization.core import encode
R=Path('.'); B=Path('outputs/single-file-parallel-20261101-01/es-419/author-01'); E=Path('localization/editorial-delivery/es-419-single-file-20261101-01'); I=Path('localization/language-imports/es-419-20261101')
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(Path(p).read_text())
def rows(p):return [json.loads(x) for x in Path(p).read_text().splitlines() if x]
def save(p,j):Path(p).write_bytes(encode(j))
def lines(p,rs):Path(p).write_text(''.join(json.dumps(x,ensure_ascii=False,separators=(',',':'))+'\n' for x in rs))
L=Path('localization/languages/es-419.json'); doc=load(L); T=doc['translations']; cat=load('localization/framework/forest045-shared-v2/catalog.json'); by={r['id']:r for r in cat};assert len(by)==len(T)==14606
assert all(r['source']==by[i]['source'] and isinstance(r['target'],str) for i,r in T.items())
assert L.read_bytes()==encode(doc)
preserve=load('localization/completion/single-file-parallel-20261101-01/shared/source-preservation.json')['baselinePreserved'];assert len(preserve)==1781
assert all(T[i]['target']==T[i]['source'] and sha(T[i]['source'].encode())==h for i,h in preserve.items())
save(B/'protected-value-proof.json',dict(passed=True,language=bind(L),catalog=bind('localization/framework/forest045-shared-v2/catalog.json'),preservation=bind('localization/completion/single-file-parallel-20261101-01/shared/source-preservation.json'),preserveExactlyCount=len(preserve),sourceHashesVerified=True,allPreservedTargetsEqualOriginal=True,completeIdSourceParity=True,compilerGuard='Full source-aware dialogue guard and resource reversals/readbacks passed in exact final artifact; deterministic only.',semanticAcceptanceAdded=False))
# Record final delta against exact pre-import null/old states, never a broad replacement.
changes={r['id']:r for r in rows(B/'authored-missing.jsonl')}
for r in rows(B/'primary-repairs.jsonl'):changes[r['id']]=r
primary=[]
for i,r in T.items():
 if i in changes:
  primary.append(dict(id=i,**r,sourceSha256=sha(r['source'].encode()),targetSha256=sha(r['target'].encode()),expectedBefore=changes[i]['expectedBefore'],authorReason=changes[i].get('reason','Directly authored from source and current es-419 glossary to resolve missing/conflicting migration target.'),authorThreadId='01a1935d-ff41-7912-9c06-55bf930b5b9e',reviewStatus='author-proofread; independent pending'))
assert len(primary)==216
lines(E/'authored-final.jsonl',primary)
I.mkdir(exist_ok=True);(I/'es-419.json').write_bytes(L.read_bytes())
# Explicit final owning artifacts. This fixed list does not consult newest files or old jobs.
paths=[Path('localization/es-419-assets/dialogue.es-419.jsonl'),Path('outputs/locale-assets-20261026/workflow-v3-completion-20261030-01/technical/0095-technical/composition-six-delivery/inputs/es-419/plan.json'),Path('localization/completion/single-file-parallel-20261101-01/es-419/managed-wording.jsonl'),Path('localization/supplemental-ui/20261027/es-419.jsonl')]
names=['inventory-descriptions','inventory-glitch','chapter-gallery','remaining51','bio113','input72','counter90','console62','pause576','ornamental569','narrative150','ui375-0074','remaining112-0076','native114-0078','native66-0080']
paths += [Path('localization/es-419-assets')/(n+'.authored.jsonl') for n in names]
paths += [Path('outputs/locale-assets-20261026/es-419/workflow-v3-completion-20261030/0084-work/inventory-titles41.authored.jsonl')]
inputs=[];exact=collections.defaultdict(list);value=collections.defaultdict(list);metadata={};own_rows={}
for p in paths:
 b=bind(p);inputs.append(b); rs=rows(p) if p.suffix=='.jsonl' else load(p)['edits']
 for n,r in enumerate(rs):
  if isinstance(r.get('source'),str) and isinstance(r.get('target'),str):
   ref=dict(path=str(p),ordinal=n+1,id=r.get('id'))
   exact[(r.get('id'),r['source'],r['target'])].append(ref);value[(r['source'],r['target'])].append(ref)
   if r.get('id') in T and r['source']==T[r['id']]['source']:
    own_rows.setdefault(r['id'],[]).append((r,p))
    metadata.setdefault(r['id'],[]).append({k:r[k] for k in ['family','hierarchy','groupId','unitId','sourceContext','sourceOccurrence','consumerOutput','consumerIds','glossaryId'] if k in r})
origins=[]
for i,r in T.items():
 if i in preserve:origin=dict(kind='exact-original-preservation',sourceHash=preserve[i])
 elif i in changes:origin=dict(kind='current-author-final',path=str(E/'authored-final.jsonl'))
 else:
  matches=exact.get((i,r['source'],r['target']))
  origin=dict(kind='exact-id-source-target' if matches else 'exact-source-target-transfer',matches=matches or value.get((r['source'],r['target']),[]))
  assert origin['matches'],i
 origins.append(dict(id=i,sourceSha256=sha(r['source'].encode()),targetSha256=sha(r['target'].encode()),origin=origin))
lines(I/'origins.jsonl',origins)
save(I/'manifest.json',dict(locale='es-419',culture='es-419',language=bind(L),snapshot=bind(I/'es-419.json'),origins=bind(I/'origins.jsonl'),inputs=inputs,sourcePreservation=bind('localization/completion/single-file-parallel-20261101-01/shared/source-preservation.json'),authorDelta=bind(E/'authored-final.jsonl'),semanticAcceptanceAddedByImport=False))
# Exact read coverage from the actual text views. Wording read != complete semantic acceptance.
dialogue=rows('localization/es-419-assets/dialogue.es-419.jsonl'); D={r['id']:r for r in dialogue}
role_cs={176,200,207,208,214,219,224,226,230,236,237,238,376,393,455,571,577,583}
whole_cs={199,422,423,428,569,303,331}
read_ids={i for i in T if not i.startswith('ds:')}
for r in dialogue:
 if ('tutorial' in r['conversation'].lower() or (r['conversationId'] in role_cs and not r['source'].endswith(':')) or r['conversationId'] in whole_cs or re.search('room.?mate|house.?mate|Finley',r['source'],re.I) or re.search(r'\b(top|bottom|switch)\b',r['source'],re.I) or re.search(r'\b(?:pasiv[oa]s?|activ[oa]s?)\b',r['target'],re.I)):
  read_ids.add(r['id'])
read_ids |=set(changes)
unread=[i for i in T if i not in read_ids]
lines(E/'primary-wording-read.jsonl',[dict(id=i,sourceSha256=sha(T[i]['source'].encode()),targetSha256=sha(T[i]['target'].encode()),coverage='literal wording read; complete author semantic verdict exists only where explicitly scoped in primary-notes.json') for i in T if i in read_ids])
(B/'unread-primary-ids.txt').write_text(''.join(i+'\n' for i in unread))
(B/'source-preserved-ids.txt').write_text(''.join(i+'\n' for i in T if i in preserve))
# Source/context packets include exact final words and original graph data, without prior judgments.
tree=load('assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json'); conv={c['id']:c for c in tree['conversations']}
nodes={}
for c in tree['conversations']:
 for n in c['dialogueEntries']:nodes[(c['id'],n['id'])]=n
contexts=[]
for i,r in D.items():
 n=nodes[(r['conversationId'],r['entryId'])]
 contexts.append(dict(id=i,conversation=r['conversation'],actorId=r['actorId'],conversantId=r['conversantId'],conditions=n['conditionsString'],script=n['userScript'],links=n['outgoingLinks'],sourceTree=bind('assets/source-v2/trees/57009919ee-sharedassets0.assets-3336.json') if not contexts else 'same-as-first-row'))
lines(E/'dialogue-context.jsonl',contexts)
packet=[]
for i,r in T.items():
 packet.append(dict(id=i,**r,sourceSha256=sha(r['source'].encode()),targetSha256=sha(r['target'].encode()),selectors=by[i]['selectors'],originalPreserved=i in preserve,contextRefs=metadata.get(i,[]),dialogueContext=dict(path=str(E/'dialogue-context.jsonl'),id=i) if i in D else None))
lines(E/'complete-final-packet.jsonl',packet)
# Cause-bound scope; mandatory regressions are separately identified and never automatic passes.
primary_ids=set(changes); dep={}; components=collections.defaultdict(list)
evidence=bind(E/'authored-final.jsonl')
def add(i,cause,reason,component):
 if i in T and i not in primary_ids:
  dep.setdefault(i,dict(id=i,causedBy=[],reason=reason,evidence={'path':evidence['path'],'sha256':evidence['sha256']}))
  if cause not in dep[i]['causedBy']:dep[i]['causedBy'].append(cause)
  components[component].append(i)
changed_by_conv=collections.defaultdict(list)
for i in primary_ids:
 if i in D:changed_by_conv[D[i]['conversationId']].append(i)
for i,r in D.items():
 for cause in changed_by_conv.get(r['conversationId'],[]):add(i,cause,'Complete containing source dialogue exchange for changed role wording; branch topology retained in dialogue-context.jsonl.','dialogue-exchange')
for i,r in T.items():
 for cause in primary_ids:
  if i!=cause and (r['source']==T[cause]['source'] or r['target']==T[cause]['target']):add(i,cause,'Exact repeated source/target wording across physical copies and consumers.','repetitions')
# All bell layers in the same four native groups; all semantic siblings form one reviewable notification.
bell_ids=set()
for i,records in metadata.items():
 if any(str(x.get('hierarchy','')).split('/')[0] in ['PurpleBellItemNotification','RedBellItemNotification','GreenBellItemNotification','BlueBellItemNotification'] for x in records):bell_ids.add(i)
bell_causes=[i for i in primary_ids if i in bell_ids]
for i in bell_ids:
 for c in bell_causes:add(i,c,'Full source-bound bell title/initial/suffix/face/glow consumer group after correcting copied color or empty styling span.','bell-consumers')
regression=set()
for r in rows('localization/framework/native-inventory-headings-20261031.jsonl'):regression.add(r['id'])
for i,r in D.items():
 if r['conversationId'] in {303,259,139,249,199,422,423,428,569}:regression.add(i)
gallery=rows('localization/source/gallery-chapter-display-20261028/admission-v1/consumer-context.jsonl')
joined=[]
for r in gallery:
 if r['id'] in T:
  assert r['source']==T[r['id']]['source'] and sha(r['source'].encode())==r['sourceUtf8Sha256']
  regression.add(r['id']);joined.append(dict(id=r['id'],source=r['source'],target=T[r['id']]['target'],sourceSha256=r['sourceUtf8Sha256'],targetSha256=sha(T[r['id']]['target'].encode()),consumer=r['consumer'],sourceDecision=r['sourceDecision']))
lines(E/'gallery-context-joined.jsonl',joined)
regression|=bell_ids
# Regression inclusion is an explicit acceptance dependency of this author batch.
for i in regression:add(i,next(iter(primary_ids & set(T))),'Mandatory regression catalog for author delta; this selection is a review assignment, never a generated pass.','mandatory-regressions')
lines(E/'dependencies.jsonl',[dep[i] for i in T if i in dep])
save(E/'closure-selector.json',dict(version=1,canonicalOrder='language translations order',primary=bind(E/'authored-final.jsonl'),rules=['containing dialogue conversation of each changed dialogue ID','exact source/target repetitions','four exact BellItemNotification hierarchy groups','mandatory regressions: twelve native inventory headings; haiku303; clothing259; transport139 and249; Finley199/422/423/428/569; exact113 gallery consumer IDs; all bell hierarchy layers'],components={k:sorted(set(v)) for k,v in components.items()},unknownBoundaries='This bounded delta does not establish a whole-corpus semantic pass. Unread full-corpus IDs are separately preserved. Fresh independent reviewer must expand a deficient closure with explicit evidence.'))
save(B/'coverage-checkpoint.json',dict(language=bind(L),catalogUnits=14606,providedTargets=14606,preservedOriginalIds=len(preserve),newOrChangedAuthoredVersions=216,literalWordingRead=len(read_ids),literalWordingUnread=len(unread),unreadIds=bind(B/'unread-primary-ids.txt'),wordingRead=bind(E/'primary-wording-read.jsonl'),fullNewSemanticAudit='incomplete; never infer completion from saved author editing or these deterministic lists',independent='pending',native='not-run'))
# Preserve old exact receipts as evidence candidates, never silently accepted current review.
retained=[]; rejected=[]; receipts_cache={}
for i,versions in own_rows.items():
 for r,p in versions:
  rec=r.get('independentReceipt')
  if not isinstance(rec,dict) or i in primary_ids or r['source']!=T[i]['source'] or r['target']!=T[i]['target']:continue
  q=Path(rec.get('path',''))
  if not q.is_file():continue
  if q not in receipts_cache:
   raw=q.read_bytes();receipts_cache[q]=(sha(raw),{sha(line):line for line in raw.splitlines(keepends=True)})
  fhash,ls=receipts_cache[q];line=ls.get(rec.get('lineSha256'))
  if fhash!=rec.get('fileSha256') or line is None:rejected.append(dict(id=i,path=str(q),reason='original receipt bytes mismatch'));continue
  rv=json.loads(line)
  if rv.get('sourceSha256')!=sha(T[i]['source'].encode()) or rv.get('targetSha256')!=sha(T[i]['target'].encode()):continue
  retained.append(dict(id=i,sourceSha256=rv['sourceSha256'],targetSha256=rv['targetSha256'],originalReceipt=dict(path=str(q),sha256=fhash,lineSha256=sha(line)),currentAcceptance='evidence-candidate only; applicable glossary/context/reviewer binding must still be reconciled; no full-corpus pass'))
lines(E/'matching-historical-receipts.jsonl',retained)
save(B/'historical-receipt-reconciliation.json',dict(exactLineBindings=len(retained),uniqueIds=len({r['id'] for r in retained}),rejected=rejected,semanticAcceptanceAdded=False))
# Process/source/glossary evidence and immutable runtime gate.
task=load(B/'task.json');failed=[]
for p,h in task['job']['immutablePins'].items():
 if sha(Path(p).read_bytes())!=h:failed.append(p)
assert not failed
save(B/'input-verification.json',dict(passed=True,pinsVerified=len(task['job']['immutablePins']),failures=failed,runtime=bind(B/'runtime-verification.json'),verifiedBeforeLocalizedInputs=True))
print(json.dumps({'language':bind(L),'authored':len(primary),'read':len(read_ids),'unread':len(unread),'dependencies':len(dep),'galleryJoined':len(joined),'historicalReceiptCandidates':len(retained),'catalogParity':True,'protectedExact':len(preserve)}))
